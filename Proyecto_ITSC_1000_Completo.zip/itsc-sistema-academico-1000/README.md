# Sistema académico ITSC

Proyecto académico para el Instituto Tecnológico Santa Cruz, realizado con PHP 8, MariaDB y XAMPP. Utiliza personas y movimientos ficticios.

**Estudiante:** Vicente Apaza Bautista  
**Docente:** Ing. Lozano Barro Jorge Robbert

## Contenido

- `itsc/`: aplicación PHP con colores institucionales y modo oscuro.
- `database/Base_de_datos_ITSC.sql`: 40 tablas y 3 vistas, con datos académicos de demostración.
- [Práctico con carátula, capturas y diagrama](docs/Practico_ITSC.docx).
- [Diagrama de clases](docs/diagramas/Diagrama_de_Clases_ITSC.svg), también disponible en PNG y PlantUML.
- `docs/capturas/`: capturas de phpMyAdmin.

## Instalación en XAMPP

1. Iniciar Apache y MySQL en XAMPP.
2. En una instalación nueva, importar `database/Base_de_datos_ITSC.sql` desde phpMyAdmin. No importar sobre una base con datos existentes.
3. Copiar `itsc/` a `C:\xampp\htdocs\itsc`.
4. Ejecutar en PowerShell:

```powershell
& C:\xampp\php\php.exe C:\xampp\htdocs\itsc\setup.php
```

5. Guardar la contraseña inicial de `admin` que muestra la consola.
6. Abrir http://localhost/itsc/ e ingresar con el acceso generado.

Si la cuenta root de MariaDB tiene contraseña, definir `ITSC_ROOT_PASSWORD` en el entorno antes de ejecutar el instalador. `setup.php` genera una cuenta de conexión propia y un archivo local `config.php`.

El SQL del repositorio no incluye usuarios de acceso, hashes de contraseñas ni registros de auditoría del equipo original. Cada instalación genera su propio acceso. Las tablas académicas conservan sus datos ficticios.

## Funciones

Estudiantes, docentes, carreras, materias, matrículas, inscripciones, evaluaciones, asistencia, resultados finales, recuperaciones, cargos, pagos, documentos, trámites y pasantías. Incluye roles ADMIN, DOCENTE y CAJA.

El diagrama de clases es un modelo de dominio simplificado; sus operaciones son propuestas de diseño. El práctico explica el alcance y las limitaciones de la aplicación. El proyecto no es un sistema oficial del instituto.

## Datos ampliados de demostración

Versión del 29 de octubre de 2026: 1.000 estudiantes, 80 docentes y 12 carreras. Las cuatro carreras adicionales están identificadas como demostración. Todos los registros añadidos son ficticios.

La exportación completa incluye estos datos; no se debe volver a cargar el SQL incremental si ya se importó la base completa. Los usuarios y registros de acceso locales fueron excluidos.

El diagrama interactivo se abre desde `docs/Diagrama_de_Clases_ITSC.html`, sin Internet. El práctico conserva el enlace al repositorio original de la entrega.

Esta versión corresponde a PHP y MariaDB para XAMPP. La migración solicitada a NestJS, Next.js y PostgreSQL todavía no está implementada.

## Versión institucional 1.4

Grupos por gestión, carrera, curso, paralelo y turno; integrantes, materias y tutor. Menú organizado por áreas, búsqueda global y paginación de 50 registros.

Consultar [la guía de grupos](docs/GUIA_GRUPOS_ITSC.md) y [las 62 verificaciones funcionales](docs/PRUEBAS_GRUPOS_ITSC.txt). El práctico y UML previos describen la versión inicial; la ampliación está documentada en la guía.
