<?php
// Exportación institucional sin dependencias externas: PDF y Office Open XML.
function reportModules():array{return ['reportes'=>['title'=>'Reportes institucionales','desc'=>'Listas por grupo y gestión, resultados y saldos. Descarga PDF o Excel según tus permisos.','fields'=>[]]];}
function reportTypes():array{
 $role=user()['rol']??'';
 if($role==='ADMIN')return ['integrantes'=>'Estudiantes por grupo','boletin'=>'Boletín de resultados','saldos'=>'Cargos pagos y saldos'];
 if($role==='DOCENTE')return ['integrantes'=>'Estudiantes de mis materias por grupo','boletin'=>'Resultados de mis materias'];
 if($role==='CAJA')return ['saldos'=>'Cargos pagos y saldos'];
 return [];
}
function reportId(string $key):?int{
 $value=$_GET[$key]??'';if($value==='')return null;
 if(!is_scalar($value)||!preg_match('/^[1-9][0-9]*$/D',(string)$value)||(float)$value>2147483647)throw new DomainException('Filtro inválido: '.$key.'.');
 return (int)$value;
}
function reportOptions():array{
 $role=user()['rol'];$params=[];$groupWhere='';$periodWhere='';
 if($role==='DOCENTE'){
  $groupWhere=' WHERE EXISTS (SELECT 1 FROM grupo_materias gm JOIN ofertas o ON o.id=gm.oferta_id WHERE gm.grupo_id=g.id AND o.docente_id=?)';
  $periodWhere=' WHERE EXISTS (SELECT 1 FROM ofertas o WHERE o.periodo_id=p.id AND o.docente_id=?)';$params=[user()['docente_id']];
 }
 $groups=rows("SELECT g.id,g.periodo_id,CONCAT(p.nombre,' · ',c.codigo,' · ',g.curso,'° ',g.paralelo,' · ',g.turno) AS label FROM grupos g JOIN carreras c ON c.id=g.carrera_id JOIN periodos p ON p.id=g.periodo_id $groupWhere ORDER BY p.fecha_inicio DESC,c.codigo,g.curso,g.paralelo",$params);
 $periods=rows("SELECT p.id,p.nombre AS label FROM periodos p $periodWhere ORDER BY p.fecha_inicio DESC,p.id DESC",$params);
 return [$groups,$periods];
}
function reportContext():array{
 if(!user()||!can('reportes'))throw new DomainException('No tienes permiso para consultar reportes.');
 $types=reportTypes();$type=$_GET['tipo']??array_key_first($types);
 if(!is_string($type)||!isset($types[$type]))throw new DomainException('No tienes permiso para ese tipo de reporte.');
 $period=reportId('gestion');$group=reportId('grupo');[$groups,$periods]=reportOptions();
 $periodMap=array_column($periods,'label','id');$groupMap=array_column($groups,null,'id');
 if($period&&!isset($periodMap[$period]))throw new DomainException('La gestión no existe o no está disponible para tu cuenta.');
 if($group&&!isset($groupMap[$group]))throw new DomainException('El grupo no existe o no está disponible para tu cuenta.');
 if($group&&$period&&(int)$groupMap[$group]['periodo_id']!==$period)throw new DomainException('El grupo seleccionado no corresponde a la gestión.');
 $label=($period?'Gestión: '.$periodMap[$period]:'Todas las gestiones').' · '.($group?'Grupo: '.$groupMap[$group]['label']:'Todos los grupos');
 return ['tipo'=>$type,'title'=>$types[$type],'gestion'=>$period,'grupo'=>$group,'label'=>$label];
}
function reportData(array $context):array{
 $period=$context['gestion'];$group=$context['grupo'];$where=' WHERE 1=1';$params=[];
 if($period){$where.=' AND mt.periodo_id=?';$params[]=$period;}
 if($group){$where.=' AND g.id=?';$params[]=$group;}
 $groupLabel="COALESCE(CONCAT(g.curso,'° ',g.paralelo,' ',g.turno),'Sin grupo')";
 $joins="JOIN matriculas mt ON mt.id=gi.matricula_id JOIN estudiantes e ON e.id=mt.estudiante_id JOIN periodos p ON p.id=mt.periodo_id";
 $numeric=[];
 if($context['tipo']==='integrantes'){
  if(user()['rol']==='DOCENTE'){$where.=" AND EXISTS (SELECT 1 FROM inscripciones i JOIN ofertas o ON o.id=i.oferta_id JOIN grupo_materias gm ON gm.oferta_id=o.id AND gm.grupo_id=g.id WHERE i.matricula_id=mt.id AND i.estado<>'RETIRADA' AND o.docente_id=?)";$params[]=user()['docente_id'];}
  $query="SELECT e.registro,CONCAT(e.apellidos,' ',e.nombres) AS estudiante,c.nombre AS carrera,p.nombre AS gestion,$groupLabel AS grupo,mt.estado FROM grupo_integrantes gi JOIN grupos g ON g.id=gi.grupo_id $joins JOIN carreras c ON c.id=mt.carrera_id $where ORDER BY p.fecha_inicio DESC,c.nombre,g.curso,g.paralelo,e.apellidos,e.nombres,e.id";
  $columns=['registro'=>'Registro','estudiante'=>'Estudiante','carrera'=>'Carrera','gestion'=>'Gestión','grupo'=>'Grupo','estado'=>'Estado'];
  $widths=[72,180,170,90,160,110];
 }elseif($context['tipo']==='boletin'){
  if(user()['rol']==='DOCENTE'){$where.=' AND o.docente_id=?';$params[]=user()['docente_id'];}
  $query="SELECT v.registro,v.estudiante,p.nombre AS gestion,$groupLabel AS grupo,v.materia,v.promedio,v.porcentaje_asistencia AS asistencia,v.nota_final,v.resultado FROM v_boletin_final v JOIN inscripciones i ON i.id=v.inscripcion_id JOIN ofertas o ON o.id=i.oferta_id JOIN matriculas mt ON mt.id=i.matricula_id JOIN periodos p ON p.id=mt.periodo_id LEFT JOIN grupo_integrantes gi ON gi.matricula_id=mt.id LEFT JOIN grupos g ON g.id=gi.grupo_id $where ORDER BY p.fecha_inicio DESC,g.id,v.registro,v.materia,v.inscripcion_id";
  $columns=['registro'=>'Registro','estudiante'=>'Estudiante','gestion'=>'Gestión','grupo'=>'Grupo','materia'=>'Materia','promedio'=>'Promedio','asistencia'=>'Asist. %','nota_final'=>'Nota final','resultado'=>'Resultado'];
  $widths=[68,125,70,92,135,55,55,55,127];$numeric=['promedio','asistencia','nota_final'];
 }else{
  if(user()['rol']!=='ADMIN'&&user()['rol']!=='CAJA')throw new DomainException('No tienes permiso para los reportes financieros.');
  $query="SELECT e.registro,CONCAT(e.apellidos,' ',e.nombres) AS estudiante,p.nombre AS gestion,$groupLabel AS grupo,v.concepto,v.cargo,v.pagado,v.saldo FROM v_saldos v JOIN matriculas mt ON mt.id=v.matricula_id JOIN estudiantes e ON e.id=mt.estudiante_id JOIN periodos p ON p.id=mt.periodo_id LEFT JOIN grupo_integrantes gi ON gi.matricula_id=mt.id LEFT JOIN grupos g ON g.id=gi.grupo_id $where ORDER BY p.fecha_inicio DESC,g.id,e.apellidos,e.nombres,v.cargo_id";
  $columns=['registro'=>'Registro','estudiante'=>'Estudiante','gestion'=>'Gestión','grupo'=>'Grupo','concepto'=>'Concepto','cargo'=>'Cargo Bs','pagado'=>'Pagado Bs','saldo'=>'Saldo Bs'];
  $widths=[75,165,80,115,145,68,68,66];$numeric=['cargo','pagado','saldo'];
 }
 return ['columns'=>$columns,'numeric'=>$numeric,'widths'=>$widths,'rows'=>rows($query,$params)];
}
function reportSelect(string $name,string $label,array $options,?int $selected=null):void{
 echo '<label class="field"><span>'.e($label).'</span><select name="'.e($name).'"><option value="">Todos</option>';
 foreach($options as $option)echo '<option value="'.e($option['id']).'" '.(isset($option['periodo_id'])?'data-periodo-id="'.e($option['periodo_id']).'" ':'').($selected===(int)$option['id']?'selected':'').'>'.e($option['label']).'</option>';
 echo '</select></label>';
}
function reportRender():void{
 try{$context=reportContext();$data=reportData($context);}catch(DomainException $ex){echo '<div class="notice error" role="alert">'.e($ex->getMessage()).'</div><a class="button secondary" href="index.php?p=reportes">Restablecer filtros</a>';return;}
 [$groups,$periods]=reportOptions();
 echo '<section class="panel"><form method="get" class="inline-form"><input type="hidden" name="p" value="reportes"><label class="field"><span>Tipo de reporte</span><select name="tipo">';
 foreach(reportTypes() as $key=>$label)echo '<option value="'.e($key).'" '.($key===$context['tipo']?'selected':'').'>'.e($label).'</option>';
 echo '</select></label>';reportSelect('gestion','Gestión',$periods,$context['gestion']);reportSelect('grupo','Grupo',$groups,$context['grupo']);
 echo '<button class="button">Consultar reporte</button></form><p class="group-help">Los filtros se aplican a la vista y a ambos archivos. Los reportes incluyen solo la información permitida para tu cuenta.</p></section>';
 $args=['p'=>'reportes','tipo'=>$context['tipo']];foreach(['gestion','grupo'] as $key)if($context[$key])$args[$key]=$context[$key];
 echo '<section class="panel"><div class="panel-heading"><div><h2>'.e($context['title']).'</h2><p class="subtle">'.e($context['label']).' · '.count($data['rows']).' registros</p></div><div class="inline-form">';
 foreach(['pdf'=>'Descargar PDF','xlsx'=>'Descargar Excel'] as $format=>$label)echo '<a class="button secondary" href="index.php?'.e(http_build_query($args+['formato'=>$format])).'">'.e($label).'</a>';
 echo '</div></div><p class="subtle">Vista previa: hasta 100 filas. Los archivos descargados incluyen todos los registros del filtro.</p>';
 $preview=[];foreach(array_slice($data['rows'],0,100) as $row){$item=[];foreach($data['columns'] as $key=>$label)$item[$label]=$row[$key];$preview[]=$item;}table($preview);echo '</section>';
}
function reportXml(string $text):string{
 $text=preg_replace('/[^\x{9}\x{A}\x{D}\x{20}-\x{D7FF}\x{E000}-\x{FFFD}]/u','',$text)??'';
 return htmlspecialchars($text,ENT_QUOTES|ENT_XML1,'UTF-8');
}
function reportColumn(int $number):string{$label='';do{$label=chr(65+$number%26).$label;$number=intdiv($number,26)-1;}while($number>=0);return $label;}
function reportZip(array $files):string{
 // ZIP en memoria: evita archivos temporales y conserva compatibilidad con Excel.
 $local='';$central='';$time=((int)date('G')<<11)|((int)date('i')<<5)|intdiv((int)date('s'),2);$date=(((int)date('Y')-1980)<<9)|((int)date('n')<<5)|(int)date('j');
 foreach($files as $name=>$content){$compressed=gzdeflate($content,6);$method=8;if($compressed===false){$compressed=$content;$method=0;}$offset=strlen($local);$crc=crc32($content);$size=strlen($content);$length=strlen($compressed);$nameLength=strlen($name);
  $local.=pack('VvvvvvVVVvv',0x04034b50,20,0,$method,$time,$date,$crc,$length,$size,$nameLength,0).$name.$compressed;
  $central.=pack('VvvvvvvVVVvvvvvVV',0x02014b50,20,20,0,$method,$time,$date,$crc,$length,$size,$nameLength,0,0,0,0,0,$offset).$name;
 }
 return $local.$central.pack('VvvvvVVv',0x06054b50,0,0,count($files),count($files),strlen($central),strlen($local),0);
}
function reportExcel(array $context,array $data):string{
 $last=reportColumn(count($data['columns'])-1);$sheetRows=[];
 $cell=function(string $address,$value,int $style=0,bool $numeric=false):string{
  if($numeric&&$value!==null&&is_numeric($value))return '<c r="'.$address.'" s="'.$style.'"><v>'.sprintf('%.8F',(float)$value).'</v></c>';
  return '<c r="'.$address.'" s="'.$style.'" t="inlineStr"><is><t xml:space="preserve">'.reportXml((string)($value??'')).'</t></is></c>';
 };
 $sheetRows[]='<row r="1" ht="25" customHeight="1">'.$cell('A1','Instituto Tecnológico Santa Cruz · '.$context['title'],2).'</row>';
 $sheetRows[]='<row r="2">'.$cell('A2',$context['label']).'</row>';
 $sheetRows[]='<row r="3">'.$cell('A3','Generado: '.date('d/m/Y H:i').' · Registros: '.count($data['rows'])).'</row>';
 $header='';$i=0;foreach($data['columns'] as $label)$header.=$cell(reportColumn($i++).'5',$label,1);$sheetRows[]='<row r="5">'.$header.'</row>';
 $rowNumber=6;
 foreach($data['rows'] as $row){$line='';$i=0;foreach($data['columns'] as $key=>$label){$isNumber=in_array($key,$data['numeric'],true);$line.=$cell(reportColumn($i++).$rowNumber,$row[$key],$isNumber?3:0,$isNumber);}$sheetRows[]='<row r="'.$rowNumber.'">'.$line.'</row>';$rowNumber++;}
 $cols='';$i=1;foreach($data['widths'] as $width){$cols.='<col min="'.$i.'" max="'.$i.'" width="'.max(12,round($width/5.5)).'" customWidth="1"/>';$i++;}
 $worksheet='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><dimension ref="A1:'.$last.max(5,$rowNumber-1).'"/><sheetViews><sheetView workbookViewId="0"><pane ySplit="5" topLeftCell="A6" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><cols>'.$cols.'</cols><sheetData>'.implode('',$sheetRows).'</sheetData><autoFilter ref="A5:'.$last.max(5,$rowNumber-1).'"/><mergeCells count="3"><mergeCell ref="A1:'.$last.'1"/><mergeCell ref="A2:'.$last.'2"/><mergeCell ref="A3:'.$last.'3"/></mergeCells><pageSetup orientation="landscape" paperSize="9"/></worksheet>';
 $files=[
 '[Content_Types].xml'=>'<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>',
 '_rels/.rels'=>'<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>',
 'xl/workbook.xml'=>'<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Reporte ITSC" sheetId="1" r:id="rId1"/></sheets></workbook>',
 'xl/_rels/workbook.xml.rels'=>'<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>',
 'xl/styles.xml'=>'<?xml version="1.0" encoding="UTF-8"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="3"><font><sz val="11"/><name val="Calibri"/></font><font><b/><color rgb="FFFFFFFF"/><sz val="11"/><name val="Calibri"/></font><font><b/><color rgb="FF075A36"/><sz val="15"/><name val="Calibri"/></font></fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF075A36"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="4"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFill="1" applyFont="1"/><xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1"/><xf numFmtId="2" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>',
 'xl/worksheets/sheet1.xml'=>$worksheet];
 return reportZip($files);
}
function reportPdfEncoded(string $text):string{return iconv('UTF-8','Windows-1252//TRANSLIT',$text)?:'';}
function reportPdfWidth(string $encoded,float $size):float{
 $width=0;foreach(str_split($encoded) as $char){if(strpos(' ilI.,:;!\'|',$char)!==false)$factor=.26;elseif(strpos('mwMW@%',$char)!==false)$factor=.86;elseif(ord($char)>=65&&ord($char)<=90)$factor=.67;else $factor=.56;$width+=$size*$factor;}return $width;
}
function reportPdfLines(string $text,float $width,float $size):array{
 $text=reportPdfEncoded(str_replace(["\r","\n","\t"],' ',$text));$words=explode(' ',$text);$lines=[];$line='';
 foreach($words as $word){$candidate=$line===''?$word:$line.' '.$word;if(reportPdfWidth($candidate,$size)<=$width){$line=$candidate;continue;}if($line!==''){$lines[]=$line;$line='';}while(reportPdfWidth($word,$size)>$width&&strlen($word)>1){$part='';while($word!==''&&reportPdfWidth($part.$word[0],$size)<=$width){$part.=$word[0];$word=substr($word,1);}if($part===''){$part=$word[0];$word=substr($word,1);}$lines[]=$part;}$line=$word;}
 if($line!==''||!$lines)$lines[]=$line;return $lines;
}
function reportPdfText(float $x,float $y,string $encoded,float $size=9,bool $bold=false):string{
 $encoded=str_replace(['\\','(',')'],['\\\\','\\(','\\)'],$encoded);
 return 'BT /'.($bold?'F2':'F1').' '.$size.' Tf 1 0 0 1 '.sprintf('%.2F %.2F',$x,$y).' Tm ('.$encoded.") Tj ET\n";
}
function reportPdf(array $context,array $data):string{
 $pageWidth=841.89;$pageHeight=595.28;$left=28.0;$tableWidth=$pageWidth-56;$sum=array_sum($data['widths']);$widths=array_map(fn($w)=>$w*$tableWidth/$sum,$data['widths']);$pageStreams=[];$stream='';$y=0;$page=0;
 $newPage=function()use(&$stream,&$y,&$page,&$pageStreams,$context,$data,$widths,$left,$pageWidth,$tableWidth):void{
  if($page)$pageStreams[]=$stream;$page++;$stream="0.03 0.35 0.21 rg\n";
  $stream.=reportPdfText($left,565,reportPdfEncoded('INSTITUTO TECNOLÓGICO SANTA CRUZ'),16,true);
  $stream.=reportPdfText($left,543,reportPdfEncoded($context['title']),12,true);$stream.="0.15 0.20 0.17 rg\n";
  $filterLines=reportPdfLines($context['label'],$tableWidth,8);$fy=526;foreach($filterLines as $line){$stream.=reportPdfText($left,$fy,$line,8);$fy-=11;}
  $stream.=reportPdfText($left,$fy-1,reportPdfEncoded('Generado: '.date('d/m/Y H:i').' · '.count($data['rows']).' registros'),8);
  $stream.=reportPdfText($pageWidth-90,20,reportPdfEncoded('Página '.$page),8);$stream.=reportPdfText($left,20,reportPdfEncoded('ITSC · Reporte del sistema académico'),8);
  $headerTop=$fy-14;$headerHeight=30;$stream.="0.03 0.35 0.21 rg\n".sprintf('%.2F %.2F %.2F %.2F re f',$left,$headerTop-$headerHeight,$tableWidth,$headerHeight)."\n1 1 1 rg\n";
  $x=$left;$index=0;foreach($data['columns'] as $label){$lines=reportPdfLines($label,$widths[$index]-9,8);$ty=$headerTop-11;foreach($lines as $line){$stream.=reportPdfText($x+4,$ty,$line,8,true);$ty-=10;}$x+=$widths[$index++];}
  $y=$headerTop-$headerHeight;
 };
 $newPage();
 foreach($data['rows'] as $rowIndex=>$row){$cellLines=[];$height=0;$i=0;foreach($data['columns'] as $key=>$label){$value=$row[$key]??'';if(in_array($key,$data['numeric'],true)&&$value!=='')$value=number_format((float)$value,2,'.',',');$lines=reportPdfLines((string)$value,$widths[$i]-9,8);$cellLines[]=$lines;$height=max($height,count($lines)*10+10);$i++;}
  if($y-$height<42)$newPage();
  $stream.=($rowIndex%2===0?"0.97 0.98 0.97":"1 1 1")." rg\n".sprintf('%.2F %.2F %.2F %.2F re f',$left,$y-$height,$tableWidth,$height)."\n0.82 0.87 0.84 RG 0.35 w\n".sprintf('%.2F %.2F m %.2F %.2F l S',$left,$y-$height,$left+$tableWidth,$y-$height)."\n0.13 0.20 0.16 rg\n";
  $x=$left;foreach($cellLines as $index=>$lines){$ty=$y-12;foreach($lines as $line){$stream.=reportPdfText($x+4,$ty,$line,8);$ty-=10;}$x+=$widths[$index];}$y-=$height;
 }
 if(!$data['rows'])$stream.=reportPdfText($left,$y-24,reportPdfEncoded('No hay registros para los filtros seleccionados.'),10);
 $pageStreams[]=$stream;$objects=[];$objects[1]='<< /Type /Catalog /Pages 2 0 R >>';$kids=[];
 $objects[3]='<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>';$objects[4]='<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>';
 foreach($pageStreams as $index=>$content){$pageId=5+$index*2;$contentId=$pageId+1;$kids[]=$pageId.' 0 R';$objects[$pageId]='<< /Type /Page /Parent 2 0 R /MediaBox [0 0 '.$pageWidth.' '.$pageHeight.'] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents '.$contentId.' 0 R >>';$objects[$contentId]='<< /Length '.strlen($content).">>\nstream\n".$content."endstream";}
 $objects[2]='<< /Type /Pages /Count '.count($pageStreams).' /Kids ['.implode(' ',$kids).'] >>';ksort($objects);$pdf="%PDF-1.4\n%\xE2\xE3\xCF\xD3\n";$offsets=[0];foreach($objects as $id=>$object){$offsets[$id]=strlen($pdf);$pdf.=$id." 0 obj\n".$object."\nendobj\n";}$xref=strlen($pdf);$pdf.='xref'."\n0 ".(count($objects)+1)."\n0000000000 65535 f \n";for($id=1;$id<=count($objects);$id++)$pdf.=sprintf('%010d 00000 n ',$offsets[$id])."\n";$pdf.='trailer << /Size '.(count($objects)+1).' /Root 1 0 R >>'."\nstartxref\n".$xref."\n%%EOF";return $pdf;
}
function reportDownload():void{
 $format=$_GET['formato']??'';if(!is_string($format)||!in_array($format,['pdf','xlsx'],true))throw new DomainException('Formato de reporte inválido.');
 $context=reportContext();$data=reportData($context);$bytes=$format==='pdf'?reportPdf($context,$data):reportExcel($context,$data);
 audit('EXPORTAR_'.strtoupper($format),'reportes',$context['tipo']);
 header('Content-Type: '.($format==='pdf'?'application/pdf':'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'));
 header('Content-Disposition: attachment; filename="ITSC_'.$context['tipo'].'_'.date('Ymd_His').'.'.$format.'"');header('Content-Length: '.strlen($bytes));header('Cache-Control: private, no-store');echo $bytes;exit;
}
