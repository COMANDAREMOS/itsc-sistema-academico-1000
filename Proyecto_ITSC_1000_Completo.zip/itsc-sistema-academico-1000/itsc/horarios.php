<?php
/** Horarios semanales. Las mutaciones se ejecutan dentro de la transacción del controlador. */
function scheduleModules():array{
 return ['horarios'=>['title'=>'Horarios y aulas','desc'=>'Organiza materias, docentes y aulas por gestión. Se validan cruces de grupo, docente y aula, incluso entre períodos con fechas superpuestas.','fields'=>[]]];
}
function scheduleDays():array{return [1=>'Lunes',2=>'Martes',3=>'Miércoles',4=>'Jueves',5=>'Viernes',6=>'Sábado',7=>'Domingo'];}
function scheduleGetId(string $name):int{
 $value=$_GET[$name]??'';if($value==='')return 0;
 if(!is_scalar($value)||!preg_match('/^[1-9][0-9]{0,9}$/D',(string)$value)||(float)$value>2147483647)throw new DomainException('Filtro de horario inválido.');
 return (int)$value;
}
function scheduleIsTeacher():bool{return user()['rol']==='DOCENTE';}
function scheduleLockPeriods():void{
 // Punto común de serialización para guardar horarios y vincular ofertas a grupos.
 // Debe adquirirse antes de grupo/oferta, siempre en el mismo orden.
 rows('SELECT id FROM periodos ORDER BY id FOR UPDATE');
}
function scheduleCheckOffer(int $id):array{
 $offer=lockOffer($id);
 $period=one('SELECT fecha_inicio,fecha_fin FROM periodos WHERE id=?',[$offer['periodo_id']]);
 if(!$period||$period['fecha_fin']<$period['fecha_inicio'])throw new DomainException('La gestión de la oferta tiene fechas inválidas.');
 $group=one('SELECT g.* FROM grupos g JOIN grupo_materias gm ON gm.grupo_id=g.id WHERE gm.oferta_id=?',[$id]);
 if($group&&$group['estado']!=='ACTIVO')throw new DomainException('El grupo está cerrado. Reábrelo antes de modificar sus horarios.');
 $offer['grupo_id']=$group?(int)$group['id']:0;
 $offer['fecha_inicio']=$period['fecha_inicio'];$offer['fecha_fin']=$period['fecha_fin'];
 return $offer;
}
function scheduleTime(string $name):string{
 $value=required($name);
 if(!preg_match('/^(?:[01][0-9]|2[0-3]):[0-5][0-9]$/D',$value))throw new DomainException('Las horas deben tener formato HH:MM, entre 00:00 y 23:59.');
 return $value.':00';
}
function scheduleMutate():void{
 if(!can('horarios',true)||user()['rol']!=='ADMIN')throw new DomainException('Solo administración puede modificar horarios.');
 scheduleLockPeriods();
 $action=(string)($_POST['action']??'save');
 if(!in_array($action,['save','retirar'],true))throw new DomainException('Operación de horario inválida.');
 $id=empty($_POST['record_id'])?null:integer('record_id');
 if($action==='retirar')$id=integer('id');
 $old=$id?one('SELECT * FROM horarios WHERE id=? FOR UPDATE',[$id]):null;
 if($id&&!$old)throw new DomainException('El horario no existe.');
 if($old)scheduleCheckOffer((int)$old['oferta_id']);
 if($action==='retirar'){
  query('DELETE FROM horarios WHERE id=?',[$id]);audit('RETIRAR_HORARIO','horarios',$id);
  $GLOBALS['saveMessage']='Horario retirado. La oferta y sus inscripciones se conservaron.';return;
 }
 $offer=scheduleCheckOffer(integer('oferta_id'));
 $room=one('SELECT * FROM aulas WHERE id=? FOR UPDATE',[integer('aula_id')]);
 if(!$room)throw new DomainException('El aula seleccionada no existe.');
 if((int)$offer['cupo']>(int)$room['capacidad'])throw new DomainException('La capacidad del aula es menor que el cupo de la oferta. Elige un aula mayor o ajusta el cupo antes de programar.');
 $day=integer('dia',1,7);$start=scheduleTime('hora_inicio');$end=scheduleTime('hora_fin');
 if($end<=$start)throw new DomainException('La hora final debe ser posterior a la inicial, dentro del mismo día.');
 $conflict=one("SELECT h.id,h.aula_id,o.docente_id,gm.grupo_id,o.id AS oferta_id FROM horarios h JOIN ofertas o ON o.id=h.oferta_id JOIN periodos p ON p.id=o.periodo_id LEFT JOIN grupo_materias gm ON gm.oferta_id=o.id WHERE h.id<>? AND h.dia=? AND h.hora_inicio<? AND h.hora_fin>? AND p.fecha_inicio<=? AND p.fecha_fin>=? AND (h.aula_id=? OR o.docente_id=? OR o.id=? OR gm.grupo_id=?) ORDER BY h.id LIMIT 1",[$id??0,$day,$end,$start,$offer['fecha_fin'],$offer['fecha_inicio'],$room['id'],$offer['docente_id'],$offer['id'],$offer['grupo_id']]);
 if($conflict){
  if((int)$conflict['oferta_id']===(int)$offer['id'])$reason='la misma materia';
  elseif((int)$conflict['aula_id']===(int)$room['id'])$reason='el aula';
  elseif((int)$conflict['docente_id']===(int)$offer['docente_id'])$reason='el docente';
  else $reason='el grupo';
  throw new DomainException('Cruce de horario: '.$reason.' ya tiene una actividad en ese intervalo (horario #'.$conflict['id'].').');
 }
 $saved=saveRow('horarios',['oferta_id'=>(int)$offer['id'],'aula_id'=>(int)$room['id'],'dia'=>$day,'hora_inicio'=>$start,'hora_fin'=>$end],$id);
 audit($id?'EDITAR_HORARIO':'CREAR_HORARIO','horarios',$saved);
 $GLOBALS['saveMessage']='Horario guardado sin cruces de grupo, docente ni aula.';
}
/** Evita crear un cruce de grupo al vincular una oferta que ya tiene horarios. */
function scheduleValidateGroupLink(int $groupId,int $offerId):void{
 $conflict=one("SELECT incoming.id FROM horarios incoming JOIN ofertas oi ON oi.id=incoming.oferta_id JOIN periodos pi ON pi.id=oi.periodo_id JOIN grupo_materias gm ON gm.grupo_id=? AND gm.oferta_id<>incoming.oferta_id JOIN horarios existing ON existing.oferta_id=gm.oferta_id AND existing.dia=incoming.dia AND existing.hora_inicio<incoming.hora_fin AND existing.hora_fin>incoming.hora_inicio JOIN ofertas oe ON oe.id=existing.oferta_id JOIN periodos pe ON pe.id=oe.periodo_id WHERE incoming.oferta_id=? AND pi.fecha_inicio<=pe.fecha_fin AND pi.fecha_fin>=pe.fecha_inicio LIMIT 1",[$groupId,$offerId]);
 if($conflict)throw new DomainException('La oferta tiene horarios que se cruzan con otra materia del grupo. Corrige primero los horarios.');
}
function scheduleOptions(array $options,$selected):void{
 echo '<option value="">Seleccionar…</option>';
 foreach($options as $option)echo '<option value="'.e($option['id']).'" '.((string)$option['id']===(string)$selected?'selected':'').'>'.e($option['label']).'</option>';
}
function scheduleGroups():array{
 $where='';$args=[];
 if(scheduleIsTeacher()){$where=' WHERE EXISTS(SELECT 1 FROM grupo_materias gm JOIN ofertas own ON own.id=gm.oferta_id WHERE gm.grupo_id=g.id AND own.docente_id=?)';$args[]=(int)user()['docente_id'];}
 return rows("SELECT g.id,CONCAT(p.nombre,' · ',c.codigo,' · ',g.curso,'° ',g.paralelo,' · ',g.turno) AS label FROM grupos g JOIN periodos p ON p.id=g.periodo_id JOIN carreras c ON c.id=g.carrera_id $where ORDER BY p.fecha_inicio DESC,c.nombre,g.curso,g.paralelo",$args);
}
function scheduleRender():void{
 try{
  $groupId=scheduleGetId('grupo');$periodId=scheduleGetId('gestion');$editId=scheduleIsTeacher()?0:scheduleGetId('edit');
  $groups=scheduleGroups();
  if($groupId&&!in_array($groupId,array_map(fn($r)=>(int)$r['id'],$groups),true))throw new DomainException('El grupo no existe o no está dentro de tus ofertas.');
  $where=' WHERE 1=1';$params=[];
  if(scheduleIsTeacher()){$where.=' AND o.docente_id=?';$params[]=(int)user()['docente_id'];}
  if($groupId){$where.=' AND gm.grupo_id=?';$params[]=$groupId;}
  if($periodId){$where.=' AND o.periodo_id=?';$params[]=$periodId;}
  $offerOptions=rows("SELECT o.id,CONCAT('#',o.id,' · ',p.nombre,' · ',ma.nombre,' · ',o.paralelo,' ',o.turno,' · ',d.nombres,' ',d.apellidos) AS label FROM ofertas o JOIN periodos p ON p.id=o.periodo_id JOIN materias ma ON ma.id=o.materia_id JOIN docentes d ON d.id=o.docente_id LEFT JOIN grupo_materias gm ON gm.oferta_id=o.id $where ORDER BY p.fecha_inicio DESC,ma.nombre,o.paralelo",$params);
  $data=rows("SELECT h.id,p.nombre AS gestion,CONCAT(c.codigo,' ',g.curso,'° ',g.paralelo,' ',g.turno) AS grupo,ma.nombre AS materia,CONCAT(d.nombres,' ',d.apellidos) AS docente,a.codigo AS aula,h.dia,h.hora_inicio,h.hora_fin FROM horarios h JOIN ofertas o ON o.id=h.oferta_id JOIN periodos p ON p.id=o.periodo_id JOIN materias ma ON ma.id=o.materia_id JOIN docentes d ON d.id=o.docente_id JOIN aulas a ON a.id=h.aula_id LEFT JOIN grupo_materias gm ON gm.oferta_id=o.id LEFT JOIN grupos g ON g.id=gm.grupo_id LEFT JOIN carreras c ON c.id=g.carrera_id $where ORDER BY p.fecha_inicio DESC,h.dia,h.hora_inicio,h.id LIMIT 1000",$params);
  $edit=null;
  if($editId){
   $edit=one('SELECT * FROM horarios WHERE id=?',[$editId]);
   if(!$edit)throw new DomainException('El horario que deseas editar no existe.');
   if(!in_array((int)$edit['oferta_id'],array_map(fn($r)=>(int)$r['id'],$offerOptions),true))throw new DomainException('El horario no pertenece a los filtros seleccionados. Limpia los filtros antes de editarlo.');
  }
  $old=$_SESSION['old']??null;
  $values=$old&&$old['page']==='horarios'?$old['data']:($edit??[]);
  if($old&&$old['page']==='horarios')unset($_SESSION['old']);
  echo '<section class="panel"><form method="get" class="inline-form"><input type="hidden" name="p" value="horarios"><label class="field"><span>Gestión</span><select name="gestion">';
  scheduleOptions(optionRows('periodos'),$periodId);echo '</select></label><label class="field"><span>Grupo</span><select name="grupo">';scheduleOptions($groups,$groupId);
  echo '</select></label><button class="button">Consultar horario</button><a class="text-button" href="index.php?p=horarios">Ver todos</a></form><p class="group-help">Los horarios son semanales. Los períodos con fechas superpuestas comparten la disponibilidad de docentes y aulas. Una actividad puede comenzar exactamente cuando termina la anterior.</p></section>';
  if(user()['rol']==='ADMIN'){
   $rooms=rows("SELECT id,CONCAT(codigo,' · capacidad ',capacidad) AS label FROM aulas ORDER BY codigo");
   echo '<details class="panel form-panel" '.(($edit||($old&&$old['page']==='horarios'))?'open':'').'><summary>'.($edit?'Editar horario #'.e($editId):'Crear horario').'</summary><form method="post" class="entry-form">';token();
   echo '<input type="hidden" name="action" value="save">';
   $record=$values['record_id']??($edit['id']??null);if($record)echo '<input type="hidden" name="record_id" value="'.e($record).'">';
   echo '<div class="form-grid"><label class="field"><span>Oferta de materia *</span><select name="oferta_id" required>';
   scheduleOptions($offerOptions,$values['oferta_id']??'');echo '</select></label><label class="field"><span>Aula *</span><select name="aula_id" required>';
   scheduleOptions($rooms,$values['aula_id']??'');echo '</select></label><label class="field"><span>Día *</span><select name="dia" required>';
   $days=[];foreach(scheduleDays() as $id=>$name)$days[]=['id'=>$id,'label'=>$name];scheduleOptions($days,$values['dia']??'');echo '</select></label>';
   foreach(['hora_inicio'=>'Hora de inicio','hora_fin'=>'Hora final'] as $key=>$label)echo '<label class="field"><span>'.e($label).' *</span><input type="time" step="60" name="'.e($key).'" required value="'.e(substr((string)($values[$key]??''),0,5)).'"></label>';
   echo '</div><div class="form-footer"><span>El cupo de la oferta no puede superar la capacidad del aula.</span><button class="button">Guardar horario</button></div></form></details>';
  }
  echo '<section class="panel records-panel"><div class="panel-heading"><h2>Horario semanal <span class="count">'.count($data).'</span></h2></div>';
  if(!$data)echo '<div class="empty">No hay horarios para esta selección. Crea una oferta y programa su aula, día y horas.</div>';
  else{
   echo '<div class="table-wrap"><table><thead><tr>';foreach(['ID','Gestión','Grupo','Materia','Docente','Aula','Día','Inicio','Fin',''] as $h)echo '<th>'.e($h).'</th>';echo '</tr></thead><tbody>';
   foreach($data as $row){echo '<tr>';foreach(['id','gestion','grupo','materia','docente','aula'] as $key)echo '<td>'.e($row[$key]??'Sin grupo').'</td>';echo '<td>'.e(scheduleDays()[(int)$row['dia']]??$row['dia']).'</td><td>'.e(substr($row['hora_inicio'],0,5)).'</td><td>'.e(substr($row['hora_fin'],0,5)).'</td><td>';
    if(user()['rol']==='ADMIN')echo '<a class="text-button" href="index.php?'.e(http_build_query(['p'=>'horarios','gestion'=>$periodId?:'','grupo'=>$groupId?:'','edit'=>$row['id']])).'">Editar</a>';
    echo '</td></tr>';}
   echo '</tbody></table></div>';
  }
  echo '<div class="table-footer">Hasta 1.000 horarios para los filtros elegidos. Los docentes consultan únicamente sus ofertas.</div></section>';
  if(user()['rol']==='ADMIN'&&$data){
   echo '<section class="panel compact-panel"><h3>Retirar un horario</h3><p class="subtle">Solo se retira la programación semanal. No se elimina la oferta ni sus estudiantes. Las ofertas y grupos cerrados no admiten cambios.</p><form method="post" class="inline-form">';token();echo '<input type="hidden" name="action" value="retirar"><label class="field"><span>Horario</span><select name="id" required><option value="">Seleccionar…</option>';
   foreach($data as $r)echo '<option value="'.e($r['id']).'">#'.e($r['id']).' · '.e($r['materia']).' · '.e(scheduleDays()[(int)$r['dia']]??$r['dia']).' '.e(substr($r['hora_inicio'],0,5)).'</option>';
   echo '</select></label><button class="button secondary">Retirar horario</button></form></section>';
  }
 }catch(DomainException $ex){echo '<div class="notice error" role="alert">'.e($ex->getMessage()).'</div><a class="button secondary" href="index.php?p=horarios">Volver a horarios</a>';}
}
