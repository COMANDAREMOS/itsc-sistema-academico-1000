<?php
function dashboardRender():void{
 $periods=rows('SELECT id,nombre FROM periodos ORDER BY fecha_inicio DESC');
 $selected=$_GET['gestion']??'';
 if($selected===''){$default=one('SELECT id FROM periodos WHERE fecha_inicio<=CURDATE() AND fecha_fin>=CURDATE() ORDER BY fecha_inicio DESC,id DESC LIMIT 1')??($periods[0]??null);$selected=$default['id']??0;}
 if(!is_scalar($selected)||!ctype_digit((string)$selected))throw new DomainException('Selecciona una gestión válida.');
 $period=one('SELECT * FROM periodos WHERE id=?',[(int)$selected]);if(!$period){echo '<section class="panel empty">Crea una gestión académica para comenzar.</section>';return;}
 [$f,$args]=offerFilter();$teacher=user()['rol']==='DOCENTE';
 $n=fn($sql,$params=[])=>query($sql,$params)->fetchColumn();
 $students=$teacher?$n("SELECT COUNT(DISTINCT mt.estudiante_id) FROM matriculas mt JOIN inscripciones i ON i.matricula_id=mt.id JOIN ofertas o ON o.id=i.oferta_id WHERE mt.periodo_id=? AND mt.estado='ACTIVA' AND i.estado<>'RETIRADA' $f",[$selected,...$args]):$n("SELECT COUNT(DISTINCT estudiante_id) FROM matriculas WHERE periodo_id=? AND estado='ACTIVA'",[$selected]);
 $groups=$teacher?$n("SELECT COUNT(*) FROM grupos g WHERE g.periodo_id=? AND EXISTS(SELECT 1 FROM grupo_materias gm JOIN ofertas o ON o.id=gm.oferta_id WHERE gm.grupo_id=g.id $f)",[$selected,...$args]):$n('SELECT COUNT(*) FROM grupos WHERE periodo_id=?',[$selected]);
 $offers=$n("SELECT COUNT(*) FROM ofertas o WHERE o.periodo_id=? $f",[$selected,...$args]);
 $approved=$n("SELECT COUNT(*) FROM v_boletin_final v JOIN inscripciones i ON i.id=v.inscripcion_id JOIN ofertas o ON o.id=i.oferta_id WHERE o.periodo_id=? AND v.resultado IN ('APROBADO','APROBADO_RECUPERACION') $f",[$selected,...$args]);
 echo '<section class="panel"><form method="get" class="inline-form"><input type="hidden" name="p" value="inicio">';rosterSelect('gestion','Gestión académica',array_map(fn($p)=>['id'=>$p['id'],'label'=>$p['nombre']],$periods),$selected);echo '<button class="button">Actualizar panel</button></form><p class="group-help">Los indicadores corresponden únicamente a la gestión seleccionada. Los estudiantes registrados sin matrícula no se cuentan como inscritos.</p></section>';
 echo '<section class="welcome-banner"><div><span class="eyebrow">INSTITUTO TECNOLÓGICO SANTA CRUZ</span><h2>Gestión '.e($period['nombre']).'</h2><p>'.e($period['fecha_inicio']).' al '.e($period['fecha_fin']).'</p></div><img class="banner-logo" src="assets/logo-itsc-v2.png" width="138" height="138" alt="Logotipo institucional"></section>';
 echo '<section class="stats-grid" aria-label="Resumen de la gestión">';foreach([['Estudiantes matriculados',$students,'Matrículas activas'],['Grupos',$groups,'Organización de la gestión'],['Ofertas de materias',$offers,'Materias y paralelos'],['Materias aprobadas',$approved,'Incluye recuperación aprobada']] as [$label,$value,$help])echo '<article class="stat"><span>'.e($label).'</span><strong>'.e($value).'</strong><small>'.e($help).'</small></article>';echo '</section>';
 if(in_array(user()['rol'],['ADMIN','CAJA'],true)){
  $charges=$n('SELECT COALESCE(SUM(c.monto),0) FROM cargos c JOIN matriculas mt ON mt.id=c.matricula_id WHERE mt.periodo_id=?',[$selected]);
  $payments=$n('SELECT COALESCE(SUM(p.monto),0) FROM pagos p JOIN cargos c ON c.id=p.cargo_id JOIN matriculas mt ON mt.id=c.matricula_id WHERE mt.periodo_id=?',[$selected]);
  echo '<section class="panel"><h2>Caja de la gestión</h2><p class="subtle">Cargos y pagos asociados a las matrículas de esta gestión, independientemente de la fecha de cobro.</p><div class="stats-grid">';foreach([['Cargos',$charges],['Cobrado',$payments],['Saldo pendiente',(float)$charges-(float)$payments]] as [$label,$value])echo '<article class="stat"><span>'.e($label).'</span><strong class="amount">Bs '.e(number_format((float)$value,2,'.',',')).'</strong></article>';echo '</div></section>';
 }
 echo '<section class="panel"><h2>Trabajo por grupo</h2><div class="quick-grid">';foreach(['inscripcion_grupal'=>['Inscripción por grupo','Seleccionar estudiantes y matricular en un lote'],'horarios'=>['Horarios y aulas','Organizar clases sin cruces'],'notas_grupo'=>['Planilla de notas','Registrar notas de la lista'],'asistencia_grupo'=>['Planilla de asistencia','Registrar presencia por sesión'],'reportes'=>['Reportes PDF y Excel','Descargar información de la gestión']] as $page=>$item)if(can($page))echo '<a class="quick-card" href="index.php?p='.e($page).'&amp;gestion='.e($selected).'"><h3>'.e($item[0]).'</h3><p>'.e($item[1]).'</p></a>';echo '</div></section>';
}
