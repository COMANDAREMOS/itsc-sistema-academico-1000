<?php
declare(strict_types=1);
date_default_timezone_set('America/La_Paz');
ini_set('session.use_strict_mode','1');
session_set_cookie_params(['httponly'=>true,'samesite'=>'Lax','secure'=>!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off']);
session_start();
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header("Content-Security-Policy: default-src 'self'; style-src 'self'; script-src 'self'; img-src 'self' data:; frame-ancestors 'none'; base-uri 'none'; form-action 'self'");
header('Cache-Control: no-store');
function e($s):string{return htmlspecialchars((string)($s??''),ENT_QUOTES,'UTF-8');}
function db():PDO{static $p; if(!$p){$c=require __DIR__.'/config.php';$p=new PDO('mysql:host=127.0.0.1;port='.$c['port'].';dbname=itsc_academico_v3;charset=utf8mb4',$c['user'],$c['password'],[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,PDO::ATTR_EMULATE_PREPARES=>false]);}return $p;}
function query(string $sql,array $args=[]):PDOStatement{$s=db()->prepare($sql);$s->execute($args);return $s;}
function rows(string $sql,array $args=[]):array{return query($sql,$args)->fetchAll();}
function one(string $sql,array $args=[]):?array{$r=query($sql,$args)->fetch();return $r?:null;}
function go(string $page='inicio'):void{header('Location: index.php?p='.rawurlencode($page),true,303);exit;}
function flash(string $message,string $type='ok'):void{$_SESSION['flash']=[$message,$type];}
function csrf():string{if(empty($_SESSION['csrf']))$_SESSION['csrf']=bin2hex(random_bytes(32));return $_SESSION['csrf'];}
function token():void{echo '<input type="hidden" name="csrf" value="'.e(csrf()).'">';}
function checkCsrf():void{if(!hash_equals(csrf(),(string)($_POST['csrf']??''))){http_response_code(403);exit('La sesión del formulario venció. Recarga la página.');}}
function user():?array{static $u=false;if($u===false)$u=empty($_SESSION['uid'])?null:one('SELECT id,usuario,nombre,rol,docente_id,activo FROM app_usuarios WHERE id=? AND activo=1',[$_SESSION['uid']]);return $u;}
function can(string $page,bool $write=false):bool{
 $u=user();if(!$u)return false;if($page==='cuenta')return true;if($u['rol']==='ADMIN')return true;
 $map=['DOCENTE'=>['inicio','ofertas','evaluaciones','notas','sesiones','asistencias','cierres','boletin','recuperaciones'], 'CAJA'=>['inicio','estudiantes','cargos','pagos','saldos']];
 if(!in_array($page,$map[$u['rol']]??[],true))return false;
 return !$write || !in_array($page,['inicio','ofertas','boletin','saldos','estudiantes'],true);
}
function audit(string $action,string $entity,$id=null):void{query('INSERT INTO app_auditoria(usuario_id,accion,entidad,registro_id) VALUES(?,?,?,?)',[user()['id'],$action,$entity,$id]);}
function required(string $key):string{$v=trim((string)($_POST[$key]??''));if($v==='')throw new DomainException('Completa todos los campos obligatorios.');return $v;}
function num(string $key,float $min,float $max):float{$v=required($key);if(!is_numeric($v)||(float)$v<$min||(float)$v>$max)throw new DomainException('Valor fuera de rango: '.$key);return (float)$v;}
function integer(string $key,int $min=1,int $max=2147483647):int{$v=required($key);if(!preg_match('/^\d+$/D',$v)||(float)$v<$min||(float)$v>$max)throw new DomainException('Número entero inválido: '.$key);return (int)$v;}
function validDate(string $key):string{$v=required($key);$d=DateTime::createFromFormat('!Y-m-d',$v);if(!$d||$d->format('Y-m-d')!==$v)throw new DomainException('Fecha inválida.');return $v;}
function lockOffer(int $id,bool $editable=true):array{
 $o=one('SELECT * FROM ofertas WHERE id=? FOR UPDATE',[$id]);
 if(!$o)throw new DomainException('Oferta inexistente.');
 if(user()['rol']==='DOCENTE'&&(int)$o['docente_id']!==(int)user()['docente_id'])throw new DomainException('No tienes acceso a esta oferta.');
 if($editable&&one('SELECT 1 FROM cierres_oferta WHERE oferta_id=?',[$id]))throw new DomainException('La oferta ya está cerrada. Sus datos académicos no se pueden modificar.');
 return $o;
}
function enrollment(int $id,bool $editable=true):array{$i=one('SELECT * FROM inscripciones WHERE id=?',[$id]);if(!$i)throw new DomainException('Inscripción inexistente.');lockOffer((int)$i['oferta_id'],$editable);if($i['estado']==='RETIRADA')throw new DomainException('Inscripción retirada.');return $i;}
function offerFilter(string $alias='o'):array{return user()['rol']==='DOCENTE'?[" AND $alias.docente_id=?",[user()['docente_id']]]:['',[]];}
function optionRows(string $kind):array{
 [$f,$a]=offerFilter();
 switch($kind){
 case 'grupos':return groupOptions();
 case 'carreras':return rows('SELECT id,nombre AS label FROM carreras ORDER BY nombre');
 case 'estudiantes':return rows("SELECT id,CONCAT(registro,' · ',nombres,' ',apellidos) AS label FROM estudiantes ORDER BY apellidos");
 case 'docentes':return rows("SELECT id,CONCAT(nombres,' ',apellidos,' · ',documento) AS label FROM docentes ORDER BY apellidos,nombres,id");
 case 'periodos':return rows('SELECT id,nombre AS label FROM periodos ORDER BY fecha_inicio DESC');
 case 'planes':return rows("SELECT p.id,CONCAT(c.nombre,' · ',p.cohorte) AS label FROM planes_estudio p JOIN carreras c ON c.id=p.carrera_id");
 case 'materias':return rows("SELECT m.id,CONCAT(c.codigo,' · ',m.codigo,' · ',m.nombre) AS label FROM materias m JOIN carreras c ON c.id=m.carrera_id ORDER BY c.nombre,m.nivel_curso,m.codigo");
 case 'ofertas':return rows("SELECT o.id,o.carrera_id,o.periodo_id,o.paralelo,o.turno,m.nivel_curso AS curso,CONCAT('#',o.id,' · ',m.nombre,' · ',p.nombre,' · ',o.paralelo) AS label FROM ofertas o JOIN materias m ON m.id=o.materia_id JOIN periodos p ON p.id=o.periodo_id WHERE 1=1 $f ORDER BY o.id",$a);
 case 'matriculas':return rows("SELECT m.id,m.carrera_id,m.periodo_id,CONCAT('#',m.id,' · ',e.registro,' · ',e.nombres,' ',e.apellidos,' · ',c.nombre,' · ',p.nombre) AS label FROM matriculas m JOIN estudiantes e ON e.id=m.estudiante_id JOIN carreras c ON c.id=m.carrera_id JOIN periodos p ON p.id=m.periodo_id WHERE m.estado='ACTIVA' ORDER BY m.id DESC");
 case 'inscripciones':return rows("SELECT i.id,CONCAT('#',i.id,' · ',e.nombres,' ',e.apellidos,' · ',ma.nombre) AS label FROM inscripciones i JOIN matriculas m ON m.id=i.matricula_id JOIN estudiantes e ON e.id=m.estudiante_id JOIN ofertas o ON o.id=i.oferta_id JOIN materias ma ON ma.id=o.materia_id WHERE i.estado<>'RETIRADA' $f ORDER BY i.id",$a);
 case 'evaluaciones':return rows("SELECT ev.id,CONCAT('#',ev.id,' · oferta ',o.id,' · ',ev.nombre,' · ',ev.componente) AS label FROM evaluaciones ev JOIN ofertas o ON o.id=ev.oferta_id WHERE 1=1 $f",$a);
 case 'sesiones':return rows("SELECT s.id,CONCAT('#',s.id,' · oferta ',o.id,' · ',s.inicio,' · ',TIMESTAMPDIFF(MINUTE,s.inicio,s.fin),' min') AS label FROM sesiones s JOIN ofertas o ON o.id=s.oferta_id WHERE s.estado='REALIZADA' $f",$a);
 case 'cargos':return rows("SELECT c.id,CONCAT('#',c.id,' · ',e.registro,' · ',c.concepto,' · saldo Bs ',v.saldo) AS label FROM cargos c JOIN matriculas m ON m.id=c.matricula_id JOIN estudiantes e ON e.id=m.estudiante_id JOIN v_saldos v ON v.cargo_id=c.id WHERE v.saldo>0 ORDER BY c.id DESC");
 case 'tipos_documento':return rows('SELECT id,nombre AS label FROM tipos_documento');
 }return [];
}
function table(array $data):void{
 if(!$data){echo '<div class="empty">Todavía no hay registros para mostrar.</div>';return;}
 echo '<div class="table-wrap"><table><thead><tr>';foreach(array_keys($data[0]) as $h)echo '<th>'.e(str_replace('_',' ',$h)).'</th>';echo '</tr></thead><tbody>';
 foreach($data as $r){echo '<tr>';foreach($r as $key=>$v){
  if($v!==null&&in_array($key,['nota','nota_final','promedio','nota_prueba','nota_registrada','nota_prueba_recuperacion','porcentaje_asistencia','peso','monto','cargo','pagado','saldo'],true))$v=number_format((float)$v,2,'.',',').($key==='porcentaje_asistencia'?' %':'');
  if($key==='excepcion_documentada')$v=$v?'Sí':'No';
  if($v!==null&&in_array($key,['resultado','estado','componente','regimen'],true))$v=ucfirst(strtolower(str_replace('_',' ',(string)$v)));
  echo '<td>'.e($v??'—').'</td>';
 }echo '</tr>';}echo '</tbody></table></div>';
}
