<?php
// Inscripción por lotes: ejecutada en una única transacción por index.php.
function bulkModules():array{return [
 'inscripcion_grupal'=>['title'=>'Inscripción por grupo','desc'=>'Selecciona varios estudiantes para crear sus matrículas y asignarlos a un grupo. Puedes inscribir también las materias vinculadas al grupo.','fields'=>[]]
];}

function bulkPositive($value,string $label):int{
 if(!is_scalar($value)||!preg_match('/^[1-9][0-9]{0,9}$/D',(string)$value)||(float)$value>2147483647)throw new DomainException('Selecciona un valor válido para '.$label.'.');
 return (int)$value;
}

function bulkEnrollOffer(array $matricula,array $offer):bool{
 $existing=one('SELECT id,estado FROM inscripciones WHERE matricula_id=? AND oferta_id=? FOR UPDATE',[$matricula['id'],$offer['id']]);
 if($existing){
  if($existing['estado']==='RETIRADA')throw new DomainException('La matrícula #'.$matricula['id'].' tiene una inscripción retirada en la oferta #'.$offer['id'].'. Revisa ese caso individualmente.');
  return false;
 }
 lockOffer((int)$offer['id']);
 if(!one('SELECT 1 FROM plan_materias WHERE plan_id=? AND materia_id=?',[$matricula['plan_id'],$offer['materia_id']]))throw new DomainException('La materia de la oferta #'.$offer['id'].' no pertenece al plan seleccionado.');
 $occupied=(int)query("SELECT COUNT(*) FROM inscripciones WHERE oferta_id=? AND estado<>'RETIRADA'",[$offer['id']])->fetchColumn();
 if($occupied>=(int)$offer['cupo'])throw new DomainException('La oferta #'.$offer['id'].' no tiene cupos suficientes para completar el lote.');
 foreach(rows('SELECT requerida_id FROM prerrequisitos WHERE plan_id=? AND materia_id=?',[$matricula['plan_id'],$offer['materia_id']]) as $pr){
  if(!one("SELECT 1 FROM v_boletin_final v JOIN inscripciones i ON i.id=v.inscripcion_id JOIN matriculas mt ON mt.id=i.matricula_id JOIN ofertas ofe ON ofe.id=i.oferta_id WHERE mt.estudiante_id=? AND ofe.materia_id=? AND v.resultado IN ('APROBADO','APROBADO_RECUPERACION')",[$matricula['estudiante_id'],$pr['requerida_id']]))throw new DomainException('El estudiante #'.$matricula['estudiante_id'].' tiene un prerrequisito pendiente. No se guardó el lote.');
 }
 $id=saveRow('inscripciones',['matricula_id'=>$matricula['id'],'oferta_id'=>$offer['id'],'carrera_id'=>$offer['carrera_id'],'periodo_id'=>$offer['periodo_id'],'fecha'=>validDate('fecha')]);
 audit('INSCRIPCION_GRUPAL','inscripciones',$id);
 return true;
}

function bulkMutate():void{
 if(!can('inscripcion_grupal',true)||user()['rol']!=='ADMIN')throw new DomainException('No tienes permiso para inscribir grupos.');
 if(($_POST['action']??'save')!=='save')throw new DomainException('Operación de inscripción grupal inválida.');
 $group=groupLock(integer('grupo_id'));
 $planId=integer('plan_id');
 $plan=one('SELECT * FROM planes_estudio WHERE id=?',[$planId]);
 if(!$plan||(int)$plan['carrera_id']!==(int)$group['carrera_id'])throw new DomainException('El plan debe pertenecer a la carrera del grupo.');
 $date=validDate('fecha');
 $input=$_POST['estudiantes']??null;
 if(!is_array($input)||!$input||count($input)>100)throw new DomainException('Selecciona entre 1 y 100 estudiantes por operación.');
 $students=[];
 foreach($input as $value)$students[]=bulkPositive($value,'estudiante');
 $students=array_values(array_unique($students));sort($students,SORT_NUMERIC);
 $withSubjects=($_POST['inscribir_materias']??'')==='1';
 $offers=[];
 if($withSubjects){
  $links=rows('SELECT oferta_id FROM grupo_materias WHERE grupo_id=? ORDER BY oferta_id',[$group['id']]);
  if(!$links)throw new DomainException('El grupo todavía no tiene materias vinculadas. Desmarca la inscripción a materias o vincula primero sus ofertas.');
  foreach($links as $link){
   $offer=lockOffer((int)$link['oferta_id'],false);
   $matter=one('SELECT nivel_curso FROM materias WHERE id=?',[$offer['materia_id']]);
   if($offer['periodo_id']!=$group['periodo_id']||$offer['carrera_id']!=$group['carrera_id']||$offer['paralelo']!==$group['paralelo']||$offer['turno']!==$group['turno']||!$matter||$matter['nivel_curso']!=$group['curso'])throw new DomainException('La oferta #'.$offer['id'].' no coincide con la organización del grupo.');
   $offers[]=$offer;
  }
 }
 $matriculas=0;$members=0;$inscriptions=0;
 foreach($students as $studentId){
  if(!one('SELECT id FROM estudiantes WHERE id=? FOR UPDATE',[$studentId]))throw new DomainException('El estudiante #'.$studentId.' no existe.');
  $matricula=one('SELECT * FROM matriculas WHERE estudiante_id=? AND carrera_id=? AND periodo_id=? FOR UPDATE',[$studentId,$group['carrera_id'],$group['periodo_id']]);
  if($matricula){
   if($matricula['estado']!=='ACTIVA')throw new DomainException('La matrícula del estudiante #'.$studentId.' no está activa. Revisa su situación individualmente.');
   if((int)$matricula['plan_id']!==$planId)throw new DomainException('El estudiante #'.$studentId.' ya tiene otro plan en esta carrera y gestión.');
  }else{
   $id=saveRow('matriculas',['estudiante_id'=>$studentId,'plan_id'=>$planId,'carrera_id'=>$group['carrera_id'],'periodo_id'=>$group['periodo_id'],'fecha'=>$date]);
   $matricula=['id'=>$id,'estudiante_id'=>$studentId,'plan_id'=>$planId,'carrera_id'=>$group['carrera_id'],'periodo_id'=>$group['periodo_id'],'estado'=>'ACTIVA'];
   $matriculas++;audit('MATRICULA_GRUPAL','matriculas',$id);
  }
  $member=one('SELECT * FROM grupo_integrantes WHERE matricula_id=? FOR UPDATE',[$matricula['id']]);
  if($member&&(int)$member['grupo_id']!==(int)$group['id'])throw new DomainException('El estudiante #'.$studentId.' ya pertenece a otro grupo en esta carrera y gestión.');
  if(!$member){
   if((int)query('SELECT COUNT(*) FROM grupo_integrantes WHERE grupo_id=?',[$group['id']])->fetchColumn()>=(int)$group['cupo'])throw new DomainException('El grupo no tiene cupos suficientes para todo el lote.');
   if(one("SELECT i.id FROM inscripciones i JOIN grupo_materias gm ON gm.oferta_id=i.oferta_id WHERE i.matricula_id=? AND gm.grupo_id<>? AND i.estado<>'RETIRADA'",[$matricula['id'],$group['id']]))throw new DomainException('El estudiante #'.$studentId.' tiene materias asociadas a otro grupo.');
   $id=saveRow('grupo_integrantes',['grupo_id'=>$group['id'],'matricula_id'=>$matricula['id']]);$members++;audit('INTEGRANTE_GRUPAL','grupo_integrantes',$id);
  }
  foreach($offers as $offer)if(bulkEnrollOffer($matricula,$offer))$inscriptions++;
 }
 $GLOBALS['saveMessage']='Lote procesado: '.count($students).' estudiantes; '.$matriculas.' matrículas nuevas, '.$members.' integrantes nuevos y '.$inscriptions.' inscripciones a materias nuevas. Los registros existentes se conservaron.';
}

function bulkRender():void{
 if(user()['rol']!=='ADMIN'||!can('inscripcion_grupal')){echo '<div class="notice error">No tienes acceso a esta pantalla.</div>';return;}
 $groupId=ctype_digit((string)($_GET['grupo']??''))?(int)$_GET['grupo']:0;
 $group=$groupId?one('SELECT g.*,p.nombre AS gestion,c.nombre AS carrera FROM grupos g JOIN periodos p ON p.id=g.periodo_id JOIN carreras c ON c.id=g.carrera_id WHERE g.id=?',[$groupId]):null;
 $plans=$group?rows('SELECT id,denominacion,cohorte FROM planes_estudio WHERE carrera_id=? ORDER BY cohorte DESC,id DESC',[$group['carrera_id']]):[];
 $selectedPlan=ctype_digit((string)($_GET['plan_id']??''))?(int)$_GET['plan_id']:0;
 if(!$selectedPlan&&count($plans)===1)$selectedPlan=(int)$plans[0]['id'];
 echo '<section class="panel"><form method="get" class="inline-form"><input type="hidden" name="p" value="inscripcion_grupal">';
 fields(['grupo'=>['Grupo','select','grupos']],['grupo'=>$groupId]);
 echo '<button class="button">Elegir grupo</button></form></section>';
 if(!$group){echo '<section class="panel"><h2>Elige un grupo para comenzar</h2><p class="subtle">Después elige su plan de estudios y marca los estudiantes que deseas incorporar.</p></section>';return;}
 $subjects=(int)query('SELECT COUNT(*) FROM grupo_materias WHERE grupo_id=?',[$group['id']])->fetchColumn();
 $occupied=(int)query('SELECT COUNT(*) FROM grupo_integrantes WHERE grupo_id=?',[$group['id']])->fetchColumn();
 echo '<section class="panel"><h2>'.e($group['gestion'].' · '.$group['carrera'].' · '.$group['curso'].'° '.$group['paralelo'].' · '.$group['turno']).'</h2><p>Integrantes: <strong>'.e($occupied).' de '.e($group['cupo']).'</strong> · Materias vinculadas: <strong>'.e($subjects).'</strong> · Estado: <strong>'.e($group['estado']).'</strong></p>';
 if($group['estado']!=='ACTIVO'){echo '<p class="notice error">Este grupo está cerrado. Puedes consultar sus datos, pero no agregar estudiantes.</p></section>';return;}
 if(!$plans){echo '<p class="notice error">La carrera no tiene planes de estudio registrados. Completa su configuración antes de matricular estudiantes.</p></section>';return;}
 echo '<form method="get" class="inline-form"><input type="hidden" name="p" value="inscripcion_grupal"><input type="hidden" name="grupo" value="'.e($groupId).'"><label class="field"><span>Plan de estudios</span><select name="plan_id" required><option value="">Seleccionar…</option>';
 foreach($plans as $plan)echo '<option value="'.e($plan['id']).'" '.($selectedPlan===$plan['id']||$selectedPlan===(int)$plan['id']?'selected':'').'>'.e($plan['denominacion'].' · '.$plan['cohorte']).'</option>';
 echo '</select></label><label class="field"><span>Buscar estudiantes</span><input type="search" name="q" value="'.e($_GET['q']??'').'" placeholder="Registro, nombre o apellido" maxlength="100"></label><button class="button secondary">Aplicar</button></form></section>';
 $validPlan=false;foreach($plans as $plan)if((int)$plan['id']===$selectedPlan)$validPlan=true;
 if(!$validPlan){echo '<section class="panel"><p class="subtle">Selecciona un plan de esta carrera para continuar.</p></section>';return;}
 $base=" FROM estudiantes e LEFT JOIN matriculas mt ON mt.estudiante_id=e.id AND mt.carrera_id=? AND mt.periodo_id=? LEFT JOIN grupo_integrantes gi ON gi.matricula_id=mt.id";
 $args=[$group['carrera_id'],$group['periodo_id']];$search=trim((string)($_GET['q']??''));
 if($search!==''){$base.=" WHERE CONCAT_WS(' ',e.registro,e.nombres,e.apellidos) LIKE ? ESCAPE '!'";$args[]='%'.str_replace(['!','%','_'],['!!','!%','!_'],substr($search,0,200)).'%';}
 $total=(int)query('SELECT COUNT(*)'.$base,$args)->fetchColumn();$pages=max(1,(int)ceil($total/50));$page=max(1,min((int)($_GET['pagina']??1),$pages));
 $students=rows('SELECT e.id,e.registro,e.nombres,e.apellidos,mt.id AS matricula_id,mt.estado,mt.plan_id,gi.grupo_id'.$base.' ORDER BY e.apellidos,e.nombres,e.id LIMIT 50 OFFSET '.(($page-1)*50),$args);
 echo '<section class="panel records-panel"><h2>Seleccionar estudiantes</h2><p class="subtle">Solo se procesa lo marcado en esta página. Hasta 100 estudiantes por envío. Si un caso no cumple las reglas, se cancela todo el lote.</p><form method="post" id="bulk-enrollment-form" data-cupos="'.e(max(0,(int)$group['cupo']-$occupied)).'">';token();
 echo '<input type="hidden" name="action" value="save"><input type="hidden" name="grupo_id" value="'.e($groupId).'"><input type="hidden" name="plan_id" value="'.e($selectedPlan).'">';
 echo '<p><button type="button" id="bulk-select-all" class="button secondary" aria-pressed="false">Seleccionar según cupo disponible</button> <span id="bulk-selected-count" aria-live="polite">0 seleccionados</span></p>';
 echo '<div class="table-wrap"><table><thead><tr><th>Seleccionar</th><th>Registro</th><th>Estudiante</th><th>Situación</th></tr></thead><tbody>';
 foreach($students as $student){
  $disabled=false;$status='Nueva matrícula e integrante';
  if($student['matricula_id'])$status='Matrícula existente';
  if($student['estado']&&$student['estado']!=='ACTIVA'){$disabled=true;$status='Matrícula '.$student['estado'];}
  elseif($student['plan_id']&&(int)$student['plan_id']!==$selectedPlan){$disabled=true;$status='Otro plan de estudios';}
  elseif($student['grupo_id']&&(int)$student['grupo_id']!==$groupId){$disabled=true;$status='Asignado a otro grupo';}
  elseif($student['grupo_id'])$status='Ya pertenece a este grupo';
  echo '<tr><td><input type="checkbox" name="estudiantes[]" value="'.e($student['id']).'" data-nuevo="'.($student['grupo_id']&&(int)$student['grupo_id']===$groupId?'0':'1').'" aria-label="Seleccionar '.e($student['registro']).'" '.($disabled?'disabled':'').'></td><td>'.e($student['registro']).'</td><td>'.e($student['apellidos'].' '.$student['nombres']).'</td><td>'.e($status).'</td></tr>';
 }
 echo '</tbody></table></div><div class="form-grid">';
 fields(['fecha'=>['Fecha de matrícula / inscripción','date']],['fecha'=>date('Y-m-d')]);
 echo '<label class="bulk-toggle"><input type="checkbox" name="inscribir_materias" value="1" '.(!$subjects?'disabled':'').'> Inscribir también las '.e($subjects).' ofertas vinculadas</label></div>';
 if(!$subjects)echo '<p class="subtle">Este grupo todavía no tiene materias vinculadas. Puedes incorporar estudiantes ahora y repetir el proceso para inscribir materias cuando estén listas.</p>';
 echo '<div class="form-footer"><span>Las matrículas e inscripciones existentes no se duplican.</span><button class="button">Procesar estudiantes seleccionados</button></div></form><div class="table-footer">Página '.e($page).' de '.e($pages).' · '.e($total).' estudiantes';
 foreach(['Anterior'=>-1,'Siguiente'=>1] as $label=>$delta){$next=$page+$delta;if($next>=1&&$next<=$pages)echo ' <a class="text-button" href="index.php?'.e(http_build_query(['p'=>'inscripcion_grupal','grupo'=>$groupId,'plan_id'=>$selectedPlan,'q'=>$search,'pagina'=>$next])).'">'.e($label).'</a>';}
 echo '</div></section>';
}
