const search=document.querySelector('#table-search');
if(search){search.addEventListener('input',()=>{const q=search.value.toLocaleLowerCase('es');let visible=0;document.querySelectorAll('tbody tr').forEach(row=>{const show=row.textContent.toLocaleLowerCase('es').includes(q);row.hidden=!show;if(show)visible++;});document.querySelector('#search-empty').hidden=visible>0;});}
document.querySelector('#print-button')?.addEventListener('click',()=>window.print());

const themeButton=document.querySelector('#theme-toggle');
function showThemeState(){
  if(!themeButton)return;
  const dark=document.documentElement.dataset.theme==='dark';
  themeButton.setAttribute('aria-pressed',String(dark));
  themeButton.setAttribute('aria-label',dark?'Cambiar a modo claro':'Cambiar a modo oscuro');
  themeButton.title=dark?'Cambiar a modo claro':'Cambiar a modo oscuro';
  themeButton.querySelector('[data-theme-icon]').textContent=dark?'☀':'☾';
  themeButton.querySelector('[data-theme-label]').textContent=dark?'Modo claro':'Modo oscuro';
}
themeButton?.addEventListener('click',()=>{
  const theme=document.documentElement.dataset.theme==='dark'?'light':'dark';
  document.documentElement.dataset.theme=theme;
  try{localStorage.setItem('itsc.theme',theme);}catch(_){}
  showThemeState();
});
window.addEventListener('storage',event=>{
  if(event.key==='itsc.theme'){
    document.documentElement.dataset.theme=event.newValue==='dark'?'dark':'light';
    showThemeState();
  }
});
showThemeState();

// Selectores con búsqueda y compatibilidad de grupos. La validación definitiva está en PHP.
document.querySelectorAll('select').forEach(select=>{
  const all=Array.from(select.options);
  let searchInput=null;
  const group=select.form?.querySelector('select[name="grupo_id"]');
  const management=select.form?.querySelector('select[name="gestion"]');
  const compatible=option=>{
    if(!option.value)return true;
    if(group && group!==select && ['matricula_id','oferta_id'].includes(select.name)){
      const selected=group.selectedOptions[0];
      if(selected?.value){for(const key of (select.name==='oferta_id'?['carreraId','periodoId','curso','paralelo','turno']:['carreraId','periodoId']))if(option.dataset[key]!==selected.dataset[key])return false;}
    }
    if(select.name==='grupo' && management?.value && option.dataset.periodoId!==management.value)return false;
    return true;
  };
  const render=()=>{
    const term=(searchInput?.value||'').toLocaleLowerCase('es');
    all.forEach(option=>{const ok=compatible(option);option.disabled=!ok;option.hidden=!ok||(option.value!==''&&!option.textContent.toLocaleLowerCase('es').includes(term));});
    if(select.selectedOptions[0]?.disabled)select.value='';
  };
  if(all.length>15){searchInput=document.createElement('input');searchInput.type='search';searchInput.className='select-search';searchInput.placeholder='Escribe para buscar una opción';searchInput.setAttribute('aria-label','Buscar opciones de '+(select.closest('label')?.querySelector('span')?.textContent||select.name));select.before(searchInput);searchInput.addEventListener('input',render);}
  if(group&&group!==select)group.addEventListener('change',()=>{if(searchInput)searchInput.value='';render();});
  if(management&&select.name==='grupo')management.addEventListener('change',render);
  render();
});
