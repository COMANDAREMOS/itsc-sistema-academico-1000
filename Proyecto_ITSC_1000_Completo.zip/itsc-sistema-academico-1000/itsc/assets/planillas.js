document.querySelectorAll('[data-attendance-fill]').forEach(button=>button.addEventListener('click',()=>{
 button.closest('form').querySelectorAll('input.roster-value:not(:disabled)').forEach(input=>{input.value=button.dataset.attendanceFill;});
}));
