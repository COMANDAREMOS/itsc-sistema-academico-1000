// Selección explícita y limitada a los estudiantes visibles de esta página.
document.addEventListener('DOMContentLoaded',()=>{
 const form=document.querySelector('#bulk-enrollment-form');
 const button=document.querySelector('#bulk-select-all');
 const count=document.querySelector('#bulk-selected-count');
 if(!form||!button||!count)return;
 const boxes=Array.from(form.querySelectorAll('input[name="estudiantes[]"]:not(:disabled)'));
 const show=()=>{
  const selected=boxes.filter(box=>box.checked).length;
  count.textContent=selected+' seleccionados';
  button.setAttribute('aria-pressed',String(selected>0));
  button.textContent=selected>0?'Desmarcar esta página':'Seleccionar según cupo disponible';
 };
 button.addEventListener('click',()=>{
  if(boxes.some(box=>box.checked)){boxes.forEach(box=>{box.checked=false;});show();return;}
  let available=Math.max(0,Number(form.dataset.cupos)||0);
  boxes.forEach(box=>{
   if(box.dataset.nuevo==='0'){box.checked=true;return;}
   if(available>0){box.checked=true;available--;}
  });show();
 });
 boxes.forEach(box=>box.addEventListener('change',show));
 button.disabled=boxes.length===0;show();
});
