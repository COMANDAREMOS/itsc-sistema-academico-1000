// Se ejecuta antes de pintar la página para evitar un destello de tema claro.
(() => {
  let theme = 'light';
  try { if (localStorage.getItem('itsc.theme') === 'dark') theme = 'dark'; } catch (_) {}
  document.documentElement.dataset.theme = theme;
})();
