<?php
// Campo: etiqueta, tipo, catálogo o valores, requerido.
$modules=[
 'estudiantes'=>['title'=>'Estudiantes','desc'=>'Registro y datos de contacto del estudiante.','fields'=>[
 'registro'=>['Registro','text'], 'documento'=>['Documento','text'],'nombres'=>['Nombres','text'],'apellidos'=>['Apellidos','text'],
 'fecha_nacimiento'=>['Fecha de nacimiento','date'],'telefono'=>['Teléfono','text',null,false],'correo'=>['Correo','email',null,false],'direccion'=>['Dirección','text',null,false]]],
 'docentes'=>['title'=>'Docentes','desc'=>'Equipo docente y especialidades.','fields'=>['documento'=>['Documento','text'],'nombres'=>['Nombres','text'],'apellidos'=>['Apellidos','text'],'especialidad'=>['Especialidad','text'],'telefono'=>['Teléfono','text',null,false],'correo'=>['Correo','email',null,false]]],
 'catalogo'=>['title'=>'Catálogo académico','desc'=>'Catálogo de carreras y materias. Las carreras adicionales, planes y cohortes de demostración están identificados en sus registros.','fields'=>[]],
 'periodos'=>['title'=>'Gestiones y períodos','desc'=>'Gestiones académicas para matrículas y ofertas.','fields'=>['nombre'=>['Nombre','text'],'fecha_inicio'=>['Inicio','date'],'fecha_fin'=>['Fin','date']]],
 'ofertas'=>['title'=>'Ofertas de materias','desc'=>'Asigna materia, docente, período y paralelo.','fields'=>['materia_id'=>['Materia','select','materias'],'periodo_id'=>['Período','select','periodos'],'docente_id'=>['Docente','select','docentes'],'paralelo'=>['Paralelo','text'],'turno'=>['Turno','enum',['MAÑANA','TARDE','NOCHE']],'cupo'=>['Cupo','number']]],
 'matriculas'=>['title'=>'Matrículas','desc'=>'Vincula al estudiante con su carrera, plan y período.','fields'=>['estudiante_id'=>['Estudiante','select','estudiantes'],'plan_id'=>['Plan y carrera','select','planes'],'periodo_id'=>['Período','select','periodos'],'fecha'=>['Fecha','date']]],
 'inscripciones'=>['title'=>'Inscripción a materias','desc'=>'La matrícula y la oferta deben corresponder a la misma carrera y período. Se controla cupo y pertenencia al plan.','fields'=>['matricula_id'=>['Matrícula','select','matriculas'],'oferta_id'=>['Oferta','select','ofertas'],'fecha'=>['Fecha','date']]],
 'evaluaciones'=>['title'=>'Evaluaciones','desc'=>'Define práctica y teoría. Los pesos deben sumar 100 dentro de cada componente al cerrar.','fields'=>['oferta_id'=>['Oferta','select','ofertas'],'nombre'=>['Evaluación','text'],'componente'=>['Componente','enum',['PRACTICA','TEORIA']],'peso'=>['Peso dentro del componente (%)','decimal']]],
 'notas'=>['title'=>'Calificaciones','desc'=>'Selecciona inscripción y evaluación de la misma oferta. Guardar de nuevo actualiza la nota mientras la oferta siga abierta.','fields'=>['inscripcion_id'=>['Inscripción','select','inscripciones'],'evaluacion_id'=>['Evaluación','select','evaluaciones'],'nota'=>['Nota (1 a 100)','decimal']]],
 'sesiones'=>['title'=>'Sesiones de clase','desc'=>'Registra sesiones realizadas. La duración se usa para calcular la asistencia.','fields'=>['oferta_id'=>['Oferta','select','ofertas'],'inicio'=>['Inicio','datetime-local'],'fin'=>['Fin','datetime-local']]],
 'asistencias'=>['title'=>'Asistencia por sesión','desc'=>'Registra minutos efectivos. Usa 0 para una falta; guardar otra vez corrige el registro mientras esté abierto.','fields'=>['inscripcion_id'=>['Inscripción','select','inscripciones'],'sesion_id'=>['Sesión realizada','select','sesiones'],'minutos_presentes'=>['Minutos presentes','number']]],
 'excepciones'=>['title'=>'Justificaciones autorizadas','desc'=>'Solo administración. Registra la referencia documental y la resolución que autoriza la excepción de asistencia.','fields'=>['inscripcion_id'=>['Inscripción','select','inscripciones'],'documento'=>['Referencia del documento','text'],'resolucion'=>['Resolución / autorización','text'],'fecha'=>['Fecha','date']]],
 'cierres'=>['title'=>'Cierre académico','desc'=>'Confirma la carga horaria para bloquear cambios en la oferta y luego calcula el resultado de cada inscripción. Completa primero notas y asistencias.','fields'=>['oferta_id'=>['Oferta','select','ofertas'],'minutos_carga'=>['Carga horaria total en minutos','number']]],
 'recuperaciones'=>['title'=>'Recuperaciones','desc'=>'Para resultados reprobados desde 40 puntos. Respeta límites por gestión y registra 61 cuando aprueba. El registro es definitivo.','fields'=>['inscripcion_id'=>['Inscripción','select','inscripciones'],'nota_prueba'=>['Nota de la prueba (1 a 100)','decimal'],'fecha'=>['Fecha','date']]],
 'boletin'=>['title'=>'Boletín de resultados','desc'=>'Resultados calculados mediante cierre académico. Imprime esta pantalla desde tu navegador.','fields'=>[]],
 'cargos'=>['title'=>'Cargos','desc'=>'Importes definidos por administración. No hay tarifas oficiales precargadas.','fields'=>['matricula_id'=>['Matrícula','select','matriculas'],'concepto'=>['Concepto','text'],'monto'=>['Importe (Bs)','decimal'],'vencimiento'=>['Vencimiento','date']]],
 'pagos'=>['title'=>'Pagos y recibos','desc'=>'Registra abonos al cargo elegido. Se bloquean importes mayores al saldo pendiente.','fields'=>['cargo_id'=>['Cargo pendiente','select','cargos'],'recibo'=>['Número de recibo','text'],'fecha'=>['Fecha','date'],'monto'=>['Importe (Bs)','decimal'],'metodo'=>['Método','enum',['EFECTIVO','TRANSFERENCIA','QR']]]],
 'saldos'=>['title'=>'Saldos pendientes','desc'=>'Detalle de cargos, abonos y saldo por estudiante.','fields'=>[]],
 'documentos'=>['title'=>'Documentación','desc'=>'Seguimiento de documentos de inscripción. Registra el estado sin almacenar archivos personales.','fields'=>['matricula_id'=>['Matrícula','select','matriculas'],'tipo_documento_id'=>['Documento','select','tipos_documento'],'estado'=>['Estado','enum',['PENDIENTE','RECIBIDO','OBSERVADO']],'observacion'=>['Observación','text',null,false]]],
 'tramites'=>['title'=>'Trámites','desc'=>'Solicitudes académicas y su seguimiento.','fields'=>['matricula_id'=>['Matrícula','select','matriculas'],'tipo'=>['Tipo','enum',['CAMBIO_CARRERA','MATERIA_REPROBADA','PRORROGA_DIPLOMA','OTRO']],'fecha'=>['Fecha','date'],'estado'=>['Estado','enum',['SOLICITADO','EN_REVISION','APROBADO','RECHAZADO']],'detalle'=>['Detalle','text',null,false]]],
 'pasantias'=>['title'=>'Pasantías','desc'=>'Registro administrativo de prácticas en empresas.','fields'=>['matricula_id'=>['Matrícula','select','matriculas'],'tutor_id'=>['Tutor','select','docentes'],'empresa'=>['Empresa','text'],'fecha_inicio'=>['Inicio','date'],'fecha_fin'=>['Fin','date',null,false],'horas'=>['Horas','number',null,false],'estado'=>['Estado','enum',['SOLICITADA','EN_CURSO','CONCLUIDA']]]],
 'usuarios'=>['title'=>'Usuarios y permisos','desc'=>'Crea accesos personales. Los docentes solo pueden operar las ofertas que tienen asignadas.','fields'=>['usuario'=>['Usuario','text'],'nombre'=>['Nombre','text'],'password'=>['Contraseña (mínimo 12 caracteres)','password'],'rol'=>['Rol','enum',['DOCENTE','CAJA','ADMIN']],'docente_id'=>['Docente asociado (obligatorio para rol docente)','select','docentes',false]]],
 'auditoria'=>['title'=>'Registro de actividad','desc'=>'Operaciones realizadas desde la aplicación.','fields'=>[]],
 'cuenta'=>['title'=>'Mi contraseña','desc'=>'Actualiza la contraseña de tu acceso personal.','fields'=>['actual'=>['Contraseña actual','password'],'nueva'=>['Nueva contraseña (mínimo 12 caracteres)','password'],'confirmacion'=>['Repite la nueva contraseña','password']]]
];

$modules=array_replace($modules,groupModules());
function listData(string $page):array{
 [$f,$a]=offerFilter();
 $queries=[
 'estudiantes'=>['SELECT id,registro,documento,nombres,apellidos,fecha_nacimiento,telefono,correo FROM estudiantes ORDER BY id DESC',[]],
 'docentes'=>['SELECT id,nombres,apellidos,especialidad,correo FROM docentes ORDER BY id DESC',[]],
 'catalogo'=>['SELECT c.nombre AS carrera,c.regimen,m.nivel_curso,m.codigo,m.nombre AS materia FROM carreras c LEFT JOIN materias m ON m.carrera_id=c.id ORDER BY c.nombre,m.nivel_curso,m.codigo',[]],
 'periodos'=>['SELECT * FROM periodos ORDER BY fecha_inicio DESC',[]],
 'ofertas'=>["SELECT o.id,m.nombre AS materia,c.nombre AS carrera,p.nombre AS periodo,CONCAT(d.nombres,' ',d.apellidos) AS docente,o.paralelo,o.turno,o.cupo,(SELECT COUNT(*) FROM inscripciones i WHERE i.oferta_id=o.id AND i.estado<>'RETIRADA') AS inscritos FROM ofertas o JOIN materias m ON m.id=o.materia_id JOIN carreras c ON c.id=o.carrera_id JOIN periodos p ON p.id=o.periodo_id JOIN docentes d ON d.id=o.docente_id WHERE 1=1 $f ORDER BY o.id DESC",$a],
 'matriculas'=>["SELECT m.id,e.registro,CONCAT(e.nombres,' ',e.apellidos) AS estudiante,c.nombre AS carrera,p.nombre AS periodo,m.estado FROM matriculas m JOIN estudiantes e ON e.id=m.estudiante_id JOIN carreras c ON c.id=m.carrera_id JOIN periodos p ON p.id=m.periodo_id ORDER BY m.id DESC",[]],
 'inscripciones'=>["SELECT i.id,m.id AS matricula,e.registro,CONCAT(e.nombres,' ',e.apellidos) AS estudiante,ma.nombre AS materia,i.oferta_id,i.estado FROM inscripciones i JOIN matriculas m ON m.id=i.matricula_id JOIN estudiantes e ON e.id=m.estudiante_id JOIN ofertas o ON o.id=i.oferta_id JOIN materias ma ON ma.id=o.materia_id ORDER BY i.id DESC",[]],
 'evaluaciones'=>["SELECT ev.id,o.id AS oferta,m.nombre AS materia,ev.nombre,ev.componente,ev.peso FROM evaluaciones ev JOIN ofertas o ON o.id=ev.oferta_id JOIN materias m ON m.id=o.materia_id WHERE 1=1 $f ORDER BY ev.id DESC",$a],
 'notas'=>["SELECT c.inscripcion_id,CONCAT(e.nombres,' ',e.apellidos) AS estudiante,o.id AS oferta,ev.nombre AS evaluacion,ev.componente,c.nota FROM calificaciones c JOIN evaluaciones ev ON ev.id=c.evaluacion_id JOIN ofertas o ON o.id=ev.oferta_id JOIN inscripciones i ON i.id=c.inscripcion_id JOIN matriculas mt ON mt.id=i.matricula_id JOIN estudiantes e ON e.id=mt.estudiante_id WHERE 1=1 $f ORDER BY c.inscripcion_id DESC",$a],
 'sesiones'=>["SELECT s.id,o.id AS oferta,m.nombre AS materia,s.inicio,s.fin,TIMESTAMPDIFF(MINUTE,s.inicio,s.fin) AS minutos,s.estado FROM sesiones s JOIN ofertas o ON o.id=s.oferta_id JOIN materias m ON m.id=o.materia_id WHERE 1=1 $f ORDER BY s.id DESC",$a],
 'asistencias'=>["SELECT a.inscripcion_id,s.id AS sesion,CONCAT(e.nombres,' ',e.apellidos) AS estudiante,s.inicio,a.minutos_presentes,TIMESTAMPDIFF(MINUTE,s.inicio,s.fin) AS minutos_sesion FROM asistencias_sesion a JOIN sesiones s ON s.id=a.sesion_id JOIN ofertas o ON o.id=s.oferta_id JOIN inscripciones i ON i.id=a.inscripcion_id JOIN matriculas mt ON mt.id=i.matricula_id JOIN estudiantes e ON e.id=mt.estudiante_id WHERE 1=1 $f ORDER BY s.inicio DESC",$a],
 'excepciones'=>['SELECT * FROM excepciones_asistencia ORDER BY fecha DESC',[]],
 'cierres'=>["SELECT c.oferta_id,m.nombre AS materia,c.minutos_carga,c.cerrado_por,c.fecha FROM cierres_oferta c JOIN ofertas o ON o.id=c.oferta_id JOIN materias m ON m.id=o.materia_id WHERE 1=1 $f ORDER BY c.fecha DESC",$a],
 'recuperaciones'=>["SELECT r.inscripcion_id,r.matricula_id,r.nota_prueba,r.nota_registrada,r.fecha FROM recuperaciones r JOIN inscripciones i ON i.id=r.inscripcion_id JOIN ofertas o ON o.id=i.oferta_id WHERE 1=1 $f ORDER BY r.fecha DESC",$a],
 'boletin'=>["SELECT v.* FROM v_boletin_final v JOIN inscripciones i ON i.id=v.inscripcion_id JOIN ofertas o ON o.id=i.oferta_id WHERE 1=1 $f ORDER BY v.registro",$a],
 'cargos'=>['SELECT c.id,e.registro,c.concepto,c.monto,c.vencimiento FROM cargos c JOIN matriculas m ON m.id=c.matricula_id JOIN estudiantes e ON e.id=m.estudiante_id ORDER BY c.id DESC',[]],
 'pagos'=>['SELECT p.id,p.recibo,e.registro,c.concepto,p.fecha,p.monto,p.metodo FROM pagos p JOIN cargos c ON c.id=p.cargo_id JOIN matriculas m ON m.id=c.matricula_id JOIN estudiantes e ON e.id=m.estudiante_id ORDER BY p.id DESC',[]],
 'saldos'=>['SELECT e.registro,CONCAT(e.nombres,\' \',e.apellidos) AS estudiante,v.* FROM v_saldos v JOIN matriculas m ON m.id=v.matricula_id JOIN estudiantes e ON e.id=m.estudiante_id ORDER BY v.saldo DESC',[]],
 'documentos'=>['SELECT d.id,d.matricula_id,t.nombre AS documento,d.estado,d.fecha_recepcion,d.observacion FROM documentos_matricula d JOIN tipos_documento t ON t.id=d.tipo_documento_id ORDER BY d.id DESC',[]],
 'tramites'=>['SELECT * FROM tramites ORDER BY id DESC',[]],
 'pasantias'=>['SELECT * FROM pasantias ORDER BY id DESC',[]],
 'usuarios'=>['SELECT id,usuario,nombre,rol,docente_id,activo FROM app_usuarios ORDER BY id',[]],
 'auditoria'=>['SELECT a.id,u.usuario,a.accion,a.entidad,a.registro_id,a.fecha FROM app_auditoria a JOIN app_usuarios u ON u.id=a.usuario_id ORDER BY a.id DESC',[]]
 ];
 $queries=array_replace($queries,groupQueries());
 if(!isset($queries[$page]))return [];
 [$q,$params]=$queries[$page];
 $source='SELECT * FROM ('.$q.' LIMIT 18446744073709551615) AS listado';
 $search=trim((string)($_GET['q']??''));
 if($search!==''){
  $meta=query($source.' LIMIT 0',$params);$columns=[];
  for($k=0;$k<$meta->columnCount();$k++){$name=$meta->getColumnMeta($k)['name'];$columns[]="COALESCE(CAST(`".str_replace('`','``',$name)."` AS CHAR),'')";}
  $source.=" WHERE CONCAT_WS(' ',".implode(',',$columns).") LIKE ?";$params[]='%'.str_replace(['!','%','_'],['!!','!%','!_'],$search).'%';
  $source.=" ESCAPE '!'";
 }
 $total=(int)query('SELECT COUNT(*) FROM ('.$source.') AS conteo',$params)->fetchColumn();
 $number=max(1,min((int)($_GET['pagina']??1),max(1,(int)ceil($total/50))));
 $GLOBALS['listing']=['total'=>$total,'page'=>$number,'pages'=>max(1,(int)ceil($total/50))];
 return rows($source.' LIMIT 50 OFFSET '.(($number-1)*50),$params);
}
