<?php
function handleLogin():void{
 checkCsrf();$name=trim((string)($_POST['usuario']??''));$key=hash('sha256',($_SERVER['REMOTE_ADDR']??'local').'|'.strtolower($name));
 $attempt=one('SELECT * FROM app_intentos WHERE clave=?',[$key]);
 if($attempt&&(int)$attempt['fallos']>=8&&strtotime($attempt['ultimo'])>time()-900){flash('Demasiados intentos. Espera 15 minutos.','error');go('login');}
 $u=one('SELECT * FROM app_usuarios WHERE usuario=? AND activo=1',[$name]);
 if(!$u||!password_verify((string)($_POST['password']??''),$u['password_hash'])){
  query('INSERT INTO app_intentos(clave,fallos,ultimo) VALUES(?,1,NOW()) ON DUPLICATE KEY UPDATE fallos=IF(ultimo<DATE_SUB(NOW(),INTERVAL 15 MINUTE),1,fallos+1),ultimo=NOW()',[$key]);
  flash('Usuario o contraseña incorrectos.','error');go('login');
 }
 query('UPDATE app_intentos SET fallos=0 WHERE clave=?',[$key]);session_regenerate_id(true);$_SESSION['uid']=$u['id'];$_SESSION['last']=time();$_SESSION['csrf']=bin2hex(random_bytes(32));audit('INICIO_SESION','usuarios',$u['id']);go();
}
function valuesFor(string $page):array{
 global $modules;$data=[];
 foreach($modules[$page]['fields'] as $key=>$field){
  $v=trim((string)($_POST[$key]??''));$req=$field[3]??true;
  if($v===''){if($req)throw new DomainException('Completa el campo '.$field[0].'.');$data[$key]=null;continue;}
  if(strlen($v)>1000)throw new DomainException('El texto es demasiado largo.');
  if($field[1]==='select')$v=integer($key);
  if($field[1]==='number')$v=integer($key,0,1000000);
  if($field[1]==='decimal')$v=num($key,0,99999999);
  if($field[1]==='enum'&&!in_array($v,$field[2],true))throw new DomainException('Opción inválida.');
  if($field[1]==='email'&&!filter_var($v,FILTER_VALIDATE_EMAIL))throw new DomainException('Correo inválido.');
  if($field[1]==='date')$v=validDate($key);
  if($field[1]==='datetime-local'){$d=DateTime::createFromFormat('!Y-m-d\TH:i',$v);if(!$d||$d->format('Y-m-d\TH:i')!==$v)throw new DomainException('Fecha u hora inválida.');$v=$d->format('Y-m-d H:i:s');}
  $data[$key]=$v;
 }return $data;
}
function saveRow(string $table,array $data,?int $id=null):int{
 $cols=array_keys($data);
 if($id){query('UPDATE '.$table.' SET '.implode(',',array_map(fn($c)=>"$c=?",$cols)).' WHERE id=?',[...array_values($data),$id]);return $id;}
 query('INSERT INTO '.$table.' ('.implode(',',$cols).') VALUES ('.implode(',',array_fill(0,count($cols),'?')).')',array_values($data));return (int)db()->lastInsertId();
}
function mutate(string $page):void{
 if(!can($page,true))throw new DomainException('No tienes permiso para esta operación.');
 $action=(string)($_POST['action']??'save');
 if(in_array($page,['grupos','integrantes','grupo_materias'],true)){groupMutate($page,$action);return;}
 if($page==='cuenta'){
  $r=one('SELECT password_hash FROM app_usuarios WHERE id=?',[user()['id']]);
  if(!password_verify(required('actual'),$r['password_hash']))throw new DomainException('La contraseña actual es incorrecta.');
  if(strlen(required('nueva'))<12||required('nueva')!==required('confirmacion'))throw new DomainException('Usa al menos 12 caracteres y confirma la misma contraseña.');
  query('UPDATE app_usuarios SET password_hash=? WHERE id=?',[password_hash(required('nueva'),PASSWORD_DEFAULT),user()['id']]);audit('CAMBIO_CLAVE','usuarios',user()['id']);return;
 }
 if($page==='usuarios'&&$action==='toggle'){
  $id=integer('id');if($id==user()['id'])throw new DomainException('No puedes desactivar tu propio acceso.');
  $target=one('SELECT id FROM app_usuarios WHERE id=? FOR UPDATE',[$id]);if(!$target)throw new DomainException('Usuario inexistente.');
  query('UPDATE app_usuarios SET activo=1-activo WHERE id=?',[$id]);audit('CAMBIO_ACCESO','usuarios',$id);return;
 }
 if($page==='cierres'&&$action==='resultado'){
  $i=enrollment(integer('inscripcion_id'),false);
  $s=query('CALL cerrar_resultado(?)',[$i['id']]);$s->closeCursor();audit('CALCULO_RESULTADO','inscripciones',$i['id']);return;
 }
 $d=valuesFor($page);$id=empty($_POST['record_id'])?null:integer('record_id');
 if($id&&!in_array($page,['estudiantes','docentes','tramites','pasantias','periodos'],true))throw new DomainException('Esta pantalla no permite editar registros.');
 if($id&&!one("SELECT id FROM $page WHERE id=? FOR UPDATE",[$id]))throw new DomainException('Registro inexistente.');
 switch($page){
 case 'estudiantes':
  if($d['fecha_nacimiento']>date('Y-m-d'))throw new DomainException('La fecha de nacimiento no puede ser futura.');
  $id=saveRow('estudiantes',$d,$id);break;
 case 'docentes':$id=saveRow('docentes',$d,$id);break;
 case 'periodos':if($d['fecha_fin']<$d['fecha_inicio'])throw new DomainException('El fin debe ser posterior al inicio.');$id=saveRow('periodos',$d,$id);break;
 case 'ofertas':
  $m=one('SELECT carrera_id FROM materias WHERE id=?',[$d['materia_id']]);if(!$m)throw new DomainException('Materia inexistente.');
  if($d['cupo']<1||$d['cupo']>65535)throw new DomainException('El cupo debe estar entre 1 y 65535.');
  $d['carrera_id']=$m['carrera_id'];$id=saveRow('ofertas',$d);break;
 case 'matriculas':
  $p=one('SELECT carrera_id FROM planes_estudio WHERE id=?',[$d['plan_id']]);if(!$p)throw new DomainException('Plan inexistente.');
  $d['carrera_id']=$p['carrera_id'];$id=saveRow('matriculas',$d);break;
 case 'inscripciones':
  $groupLink=one('SELECT grupo_id FROM grupo_materias WHERE oferta_id=?',[$d['oferta_id']]);
  if($groupLink){groupLock((int)$groupLink['grupo_id']);if(!one('SELECT id FROM grupo_integrantes WHERE grupo_id=? AND matricula_id=?',[$groupLink['grupo_id'],$d['matricula_id']]))throw new DomainException('La matrícula debe pertenecer al grupo de esta materia antes de inscribirla.');}
  $o=lockOffer($d['oferta_id']);$m=one("SELECT * FROM matriculas WHERE id=? AND estado='ACTIVA' FOR UPDATE",[$d['matricula_id']]);
  if(!$m||$m['carrera_id']!=$o['carrera_id']||$m['periodo_id']!=$o['periodo_id'])throw new DomainException('La oferta debe coincidir con la carrera y el período de la matrícula.');
  if(!one('SELECT 1 FROM plan_materias WHERE plan_id=? AND materia_id=?',[$m['plan_id'],$o['materia_id']]))throw new DomainException('La materia no pertenece al plan de la matrícula.');
  if((int)query("SELECT COUNT(*) FROM inscripciones WHERE oferta_id=? AND estado<>'RETIRADA'",[$o['id']])->fetchColumn()>=(int)$o['cupo'])throw new DomainException('La oferta ya no tiene cupos disponibles.');
  foreach(rows('SELECT requerida_id FROM prerrequisitos WHERE plan_id=? AND materia_id=?',[$m['plan_id'],$o['materia_id']]) as $pr){
   if(!one("SELECT 1 FROM v_boletin_final v JOIN inscripciones i ON i.id=v.inscripcion_id JOIN matriculas mt ON mt.id=i.matricula_id JOIN ofertas ofe ON ofe.id=i.oferta_id WHERE mt.estudiante_id=? AND ofe.materia_id=? AND v.resultado IN ('APROBADO','APROBADO_RECUPERACION')",[$m['estudiante_id'],$pr['requerida_id']]))throw new DomainException('El estudiante tiene un prerrequisito pendiente.');
  }
  $d['carrera_id']=$o['carrera_id'];$d['periodo_id']=$o['periodo_id'];$id=saveRow('inscripciones',$d);break;
 case 'evaluaciones':
  lockOffer($d['oferta_id']);if($d['peso']<=0||$d['peso']>100)throw new DomainException('El peso debe ser mayor a 0 y máximo 100.');
  $sum=(float)query('SELECT COALESCE(SUM(peso),0) FROM evaluaciones WHERE oferta_id=? AND componente=?',[$d['oferta_id'],$d['componente']])->fetchColumn();
  if($sum+$d['peso']>100.00001)throw new DomainException('Los pesos de este componente excederían el 100 %.');
  $id=saveRow('evaluaciones',$d);break;
 case 'notas':
  $i=enrollment($d['inscripcion_id']);$ev=one('SELECT * FROM evaluaciones WHERE id=?',[$d['evaluacion_id']]);
  if(!$ev||$ev['oferta_id']!=$i['oferta_id'])throw new DomainException('La evaluación y la inscripción deben pertenecer a la misma oferta.');
  if($d['nota']<1||$d['nota']>100)throw new DomainException('La nota debe estar entre 1 y 100.');
  query('INSERT INTO calificaciones(inscripcion_id,evaluacion_id,oferta_id,nota) VALUES(?,?,?,?) ON DUPLICATE KEY UPDATE nota=VALUES(nota)',[$i['id'],$ev['id'],$i['oferta_id'],$d['nota']]);$id=$i['id'];break;
 case 'sesiones':
  lockOffer($d['oferta_id']);if(strtotime($d['fin'])<=strtotime($d['inicio'])||strtotime($d['fin'])-strtotime($d['inicio'])>65535*60)throw new DomainException('Revisa la duración de la sesión.');
  $d['estado']='REALIZADA';$id=saveRow('sesiones',$d);break;
 case 'asistencias':
  $i=enrollment($d['inscripcion_id']);$s=one("SELECT * FROM sesiones WHERE id=? AND estado='REALIZADA'",[$d['sesion_id']]);
  if(!$s||$s['oferta_id']!=$i['oferta_id'])throw new DomainException('La sesión y la inscripción deben pertenecer a la misma oferta.');
  if($d['minutos_presentes']>(strtotime($s['fin'])-strtotime($s['inicio']))/60)throw new DomainException('Los minutos presentes superan la duración de la sesión.');
  query('INSERT INTO asistencias_sesion(inscripcion_id,sesion_id,oferta_id,minutos_presentes) VALUES(?,?,?,?) ON DUPLICATE KEY UPDATE minutos_presentes=VALUES(minutos_presentes)',[$i['id'],$s['id'],$i['oferta_id'],$d['minutos_presentes']]);$id=$i['id'];break;
 case 'excepciones':
  $i=enrollment($d['inscripcion_id']);$d['aprobada_por']=user()['nombre'];$id=saveRow('excepciones_asistencia',$d);break;
 case 'cierres':
  $o=lockOffer($d['oferta_id']);$total=(int)query("SELECT COALESCE(SUM(TIMESTAMPDIFF(MINUTE,inicio,fin)),0) FROM sesiones WHERE oferta_id=? AND estado='REALIZADA'",[$o['id']])->fetchColumn();
  if(!$total||$d['minutos_carga']!==$total)throw new DomainException('La carga debe coincidir con la suma de minutos de las sesiones realizadas.');
  if(one("SELECT 1 FROM sesiones WHERE oferta_id=? AND estado='PROGRAMADA'",[$o['id']]))throw new DomainException('Existen sesiones programadas pendientes.');
  if((int)query('SELECT COUNT(*) FROM (SELECT componente FROM evaluaciones WHERE oferta_id=? GROUP BY componente HAVING SUM(peso)=100) t',[$o['id']])->fetchColumn()!==2)throw new DomainException('Completa el 100 % de práctica y teoría antes de cerrar.');
  if(!one("SELECT 1 FROM inscripciones WHERE oferta_id=? AND estado<>'RETIRADA'",[$o['id']]))throw new DomainException('La oferta no tiene inscritos activos.');
  foreach(rows("SELECT id FROM inscripciones WHERE oferta_id=? AND estado<>'RETIRADA'",[$o['id']]) as $ins){
   if(one('SELECT 1 FROM evaluaciones ev LEFT JOIN calificaciones c ON c.evaluacion_id=ev.id AND c.inscripcion_id=? WHERE ev.oferta_id=? AND c.inscripcion_id IS NULL',[$ins['id'],$o['id']]))throw new DomainException('Hay estudiantes con calificaciones pendientes.');
   if(one("SELECT 1 FROM sesiones s LEFT JOIN asistencias_sesion a ON a.sesion_id=s.id AND a.inscripcion_id=? WHERE s.oferta_id=? AND s.estado='REALIZADA' AND a.inscripcion_id IS NULL",[$ins['id'],$o['id']]))throw new DomainException('Hay estudiantes con asistencia pendiente.');
  }
  $d['cerrado_por']=user()['nombre'];$id=saveRow('cierres_oferta',$d);break;
 case 'recuperaciones':
  $i=enrollment($d['inscripcion_id'],false);if($d['nota_prueba']<1||$d['nota_prueba']>100)throw new DomainException('La nota debe estar entre 1 y 100.');
  $d['matricula_id']=$i['matricula_id'];$d['nota_registrada']=$d['nota_prueba'];$id=saveRow('recuperaciones',$d);break;
 case 'cargos':if($d['monto']<=0)throw new DomainException('El importe debe ser positivo.');$id=saveRow('cargos',$d);break;
 case 'pagos':
  if(!one('SELECT id FROM cargos WHERE id=? FOR UPDATE',[$d['cargo_id']]))throw new DomainException('Cargo inexistente.');
  $saldo=one('SELECT saldo FROM v_saldos WHERE cargo_id=?',[$d['cargo_id']]);
  if($d['monto']<=0||round($d['monto']*100)>round((float)$saldo['saldo']*100))throw new DomainException('El importe debe ser positivo y no superar el saldo pendiente.');
  $id=saveRow('pagos',$d);break;
 case 'documentos':
  query('INSERT INTO documentos_matricula(matricula_id,tipo_documento_id,estado,fecha_recepcion,observacion) VALUES(?,?,?,?,?) ON DUPLICATE KEY UPDATE estado=VALUES(estado),fecha_recepcion=VALUES(fecha_recepcion),observacion=VALUES(observacion)',[$d['matricula_id'],$d['tipo_documento_id'],$d['estado'],$d['estado']==='RECIBIDO'?date('Y-m-d'):null,$d['observacion']]);$id=$d['matricula_id'];break;
 case 'tramites':$id=saveRow('tramites',$d,$id);break;
 case 'pasantias':if($d['fecha_fin']&&$d['fecha_fin']<$d['fecha_inicio'])throw new DomainException('Revisa las fechas de la pasantía.');$id=saveRow('pasantias',$d,$id);break;
 case 'usuarios':
  if(strlen($d['password'])<12)throw new DomainException('Usa al menos 12 caracteres para la contraseña.');
  if(!preg_match('/^[a-zA-Z0-9_.-]{3,60}$/D',$d['usuario']))throw new DomainException('Usuario: entre 3 y 60 letras, números, punto, guion o guion bajo.');
  if($d['rol']==='DOCENTE'&&!$d['docente_id'])throw new DomainException('Asocia una persona docente al acceso.');
  $d['password_hash']=password_hash($d['password'],PASSWORD_DEFAULT);unset($d['password']);if($d['rol']!=='DOCENTE')$d['docente_id']=null;
  $id=saveRow('app_usuarios',$d);break;
 default:throw new DomainException('Operación no disponible.');
 }
 audit($action==='save'?'GUARDAR':$action,$page,$id);
}
