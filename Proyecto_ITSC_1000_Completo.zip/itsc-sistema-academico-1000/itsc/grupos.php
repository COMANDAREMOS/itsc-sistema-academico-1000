<?php
// Organización institucional. Todas las escrituras requieren rol ADMIN y CSRF.
function groupModules():array{return [
 'grupos'=>['title'=>'Grupos por gestión','desc'=>'Organiza cada grupo por gestión, carrera, curso, paralelo y turno. La asignación al grupo no sustituye la inscripción a materias.','fields'=>[
 'periodo_id'=>['Gestión / período','select','periodos'],'carrera_id'=>['Carrera','select','carreras'],'curso'=>['Curso / nivel (1 a 6)','number'],'paralelo'=>['Paralelo','text'],'turno'=>['Turno','enum',['MAÑANA','TARDE','NOCHE']],'cupo'=>['Cupo máximo (1 a 1000)','number'],'tutor_id'=>['Docente tutor','select','docentes',false],'estado'=>['Estado','enum',['ACTIVO','CERRADO']]]],
 'integrantes'=>['title'=>'Estudiantes por grupo','desc'=>'Asigna una matrícula activa a un grupo de su misma carrera y gestión. Cada matrícula pertenece a un solo grupo.','fields'=>['grupo_id'=>['Grupo de destino','select','grupos'],'matricula_id'=>['Matrícula activa','select','matriculas']]],
 'grupo_materias'=>['title'=>'Materias por grupo','desc'=>'Vincula las ofertas del mismo curso, carrera, gestión, paralelo y turno. El docente se asigna en la oferta de materia.','fields'=>['grupo_id'=>['Grupo','select','grupos'],'oferta_id'=>['Oferta de materia','select','ofertas']]]
 ];}
function groupOptions():array{return rows("SELECT g.id,CONCAT(p.nombre,' · ',c.codigo,' · ',g.curso,'° ',g.paralelo,' · ',g.turno,' · ',g.estado) AS label,g.periodo_id,g.carrera_id,g.curso,g.paralelo,g.turno FROM grupos g JOIN periodos p ON p.id=g.periodo_id JOIN carreras c ON c.id=g.carrera_id ORDER BY p.fecha_inicio DESC,c.nombre,g.curso,g.paralelo");}
function groupQueries():array{
 $w=' WHERE 1=1';$params=[];
 foreach(['gestion'=>'g.periodo_id','grupo'=>'g.id'] as $key=>$col)if(ctype_digit((string)($_GET[$key]??''))&&(int)$_GET[$key]>0){$w.=" AND $col=?";$params[]=(int)$_GET[$key];}
 return [
 'grupos'=>["SELECT g.id,p.nombre AS gestion,c.nombre AS carrera,g.curso,g.paralelo,g.turno,g.cupo,(SELECT COUNT(*) FROM grupo_integrantes gi JOIN matriculas mt ON mt.id=gi.matricula_id WHERE gi.grupo_id=g.id AND mt.estado='ACTIVA') AS estudiantes,(SELECT COUNT(*) FROM grupo_materias gm WHERE gm.grupo_id=g.id) AS materias,CONCAT(d.nombres,' ',d.apellidos) AS tutor,g.estado FROM grupos g JOIN periodos p ON p.id=g.periodo_id JOIN carreras c ON c.id=g.carrera_id LEFT JOIN docentes d ON d.id=g.tutor_id $w ORDER BY p.fecha_inicio DESC,c.nombre,g.curso,g.paralelo",$params],
 'integrantes'=>["SELECT gi.id,p.nombre AS gestion,c.nombre AS carrera,CONCAT(g.curso,'° ',g.paralelo,' · ',g.turno) AS grupo,e.registro,CONCAT(e.apellidos,' ',e.nombres) AS estudiante,mt.id AS matricula,mt.estado FROM grupo_integrantes gi JOIN grupos g ON g.id=gi.grupo_id JOIN periodos p ON p.id=g.periodo_id JOIN carreras c ON c.id=g.carrera_id JOIN matriculas mt ON mt.id=gi.matricula_id JOIN estudiantes e ON e.id=mt.estudiante_id $w ORDER BY p.fecha_inicio DESC,g.id,e.apellidos,e.nombres",$params],
 'grupo_materias'=>["SELECT gm.id,p.nombre AS gestion,c.nombre AS carrera,CONCAT(g.curso,'° ',g.paralelo,' · ',g.turno) AS grupo,ma.nombre AS materia,CONCAT(d.nombres,' ',d.apellidos) AS docente,o.cupo AS cupo_materia FROM grupo_materias gm JOIN grupos g ON g.id=gm.grupo_id JOIN periodos p ON p.id=g.periodo_id JOIN carreras c ON c.id=g.carrera_id JOIN ofertas o ON o.id=gm.oferta_id JOIN materias ma ON ma.id=o.materia_id JOIN docentes d ON d.id=o.docente_id $w ORDER BY p.fecha_inicio DESC,g.id,ma.nombre",$params]
 ];
}
function groupLock(int $id):array{
 $g=one('SELECT * FROM grupos WHERE id=? FOR UPDATE',[$id]);
 if(!$g)throw new DomainException('El grupo no existe.');
 if($g['estado']!=='ACTIVO')throw new DomainException('El grupo está cerrado. No admite nuevas asignaciones.');
 return $g;
}
function groupMutate(string $page,string $action):void{
 if($action==='retirar'){
  if(!in_array($page,['integrantes','grupo_materias'],true))throw new DomainException('Operación inválida.');
  $table=$page==='integrantes'?'grupo_integrantes':'grupo_materias';$id=integer('id');
  $r=one("SELECT * FROM $table WHERE id=?",[$id]);if(!$r)throw new DomainException('La asignación no existe.');
  groupLock((int)$r['grupo_id']);
  // Mantener la relación mientras existan inscripciones activas asociadas.
  if($page==='grupo_materias'&&one("SELECT id FROM inscripciones WHERE oferta_id=? AND estado<>'RETIRADA'",[$r['oferta_id']]))throw new DomainException('La oferta tiene inscripciones. No se puede desvincular.');
  if($page==='integrantes'&&one("SELECT i.id FROM inscripciones i JOIN grupo_materias gm ON gm.oferta_id=i.oferta_id WHERE gm.grupo_id=? AND i.matricula_id=? AND i.estado<>'RETIRADA'",[$r['grupo_id'],$r['matricula_id']]))throw new DomainException('La matrícula tiene materias del grupo. Retira primero esas inscripciones.');
  query("DELETE FROM $table WHERE id=?",[$id]);audit('RETIRAR_ASIGNACION',$page,$id);return;
 }
 $d=valuesFor($page);
 if($page==='grupos'){
  $id=empty($_POST['record_id'])?null:integer('record_id');
  $d['paralelo']=strtoupper(trim($d['paralelo']));
  if(!preg_match('/^[A-Z0-9-]{1,10}$/D',$d['paralelo']))throw new DomainException('El paralelo admite letras, números y guiones, hasta 10 caracteres.');
  if($d['curso']<1||$d['curso']>6||$d['cupo']<1||$d['cupo']>1000)throw new DomainException('Usa curso entre 1 y 6 y cupo entre 1 y 1000.');
  if(!one('SELECT id FROM carreras WHERE id=? AND activa=1',[$d['carrera_id']]))throw new DomainException('Selecciona una carrera activa.');
  if($id){
   $old=one('SELECT * FROM grupos WHERE id=? FOR UPDATE',[$id]);if(!$old)throw new DomainException('El grupo no existe.');
   $n=(int)query('SELECT COUNT(*) FROM grupo_integrantes WHERE grupo_id=?',[$id])->fetchColumn();
   if($d['cupo']<$n)throw new DomainException('El cupo no puede ser menor que el número de integrantes.');
   if($n||one('SELECT id FROM grupo_materias WHERE grupo_id=?',[$id]))foreach(['periodo_id','carrera_id','curso','paralelo','turno'] as $key)if((string)$old[$key] !== (string)$d[$key])throw new DomainException('El grupo ya tiene asignaciones. Conserva gestión, carrera, curso, paralelo y turno; crea otro grupo para cambiarlos.');
  }
  $saved=saveRow('grupos',$d,$id);audit('GUARDAR','grupos',$saved);return;
 }
 if($page==='grupo_materias')scheduleLockPeriods();
 $g=groupLock($d['grupo_id']);
 if($page==='integrantes'){
  $m=one('SELECT * FROM matriculas WHERE id=? FOR UPDATE',[$d['matricula_id']]);
  if(!$m||$m['estado']!=='ACTIVA'||$m['periodo_id']!=$g['periodo_id']||$m['carrera_id']!=$g['carrera_id'])throw new DomainException('La matrícula debe estar activa y coincidir con la carrera y gestión del grupo.');
  if(one('SELECT id FROM grupo_integrantes WHERE matricula_id=?',[$m['id']]))throw new DomainException('La matrícula ya pertenece a un grupo.');
  if((int)query('SELECT COUNT(*) FROM grupo_integrantes WHERE grupo_id=?',[$g['id']])->fetchColumn()>=$g['cupo'])throw new DomainException('El grupo alcanzó su cupo máximo.');
  if(one("SELECT i.id FROM inscripciones i JOIN grupo_materias gm ON gm.oferta_id=i.oferta_id WHERE i.matricula_id=? AND gm.grupo_id<>? AND i.estado<>'RETIRADA'",[$m['id'],$g['id']]))throw new DomainException('La matrícula tiene materias asignadas a otro grupo.');
  $id=saveRow('grupo_integrantes',$d);
 }else{
  $o=lockOffer($d['oferta_id']);$ma=one('SELECT nivel_curso FROM materias WHERE id=?',[$o['materia_id']]);
  if($o['periodo_id']!=$g['periodo_id']||$o['carrera_id']!=$g['carrera_id']||$ma['nivel_curso']!=$g['curso']||$o['paralelo']!==$g['paralelo']||$o['turno']!==$g['turno'])throw new DomainException('La oferta debe coincidir con gestión, carrera, curso, paralelo y turno del grupo.');
  if(one("SELECT i.id FROM inscripciones i LEFT JOIN grupo_integrantes gi ON gi.matricula_id=i.matricula_id AND gi.grupo_id=? WHERE i.oferta_id=? AND i.estado<>'RETIRADA' AND gi.id IS NULL",[$g['id'],$o['id']]))throw new DomainException('La oferta tiene estudiantes que todavía no pertenecen a este grupo. Asígnalos primero.');
  scheduleValidateGroupLink((int)$g['id'],(int)$o['id']);
  $id=saveRow('grupo_materias',$d);
 }
 audit('ASIGNAR',$page,$id);
}
function groupFilters(string $page):void{
 if(!in_array($page,['grupos','integrantes','grupo_materias'],true))return;
 echo '<section class="panel"><form method="get" class="inline-form group-filter"><input type="hidden" name="p" value="'.e($page).'">';
 fields(['gestion'=>['Filtrar gestión','select','periodos',false],'grupo'=>['Filtrar grupo','select','grupos',false]],$_GET);
 echo '<button class="button">Aplicar filtros</button><a class="text-button" href="index.php?p='.e($page).'">Ver todos</a></form><p class="group-help">1. Crear gestión → 2. Crear grupo → 3. Matricular estudiantes → 4. Asignar integrantes → 5. Vincular ofertas → 6. Inscribir materias.</p></section>';
}
