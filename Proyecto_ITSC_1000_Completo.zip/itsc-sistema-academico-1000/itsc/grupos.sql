-- Ampliación no destructiva para grupos por gestión y carrera.
USE itsc_academico_v3;
CREATE TABLE IF NOT EXISTS grupos (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 periodo_id INT UNSIGNED NOT NULL,
 carrera_id INT UNSIGNED NOT NULL,
 curso TINYINT UNSIGNED NOT NULL,
 paralelo VARCHAR(20) NOT NULL,
 turno ENUM('MAÑANA','TARDE','NOCHE') NOT NULL,
 cupo SMALLINT UNSIGNED NOT NULL,
 tutor_id INT UNSIGNED NULL,
 estado ENUM('ACTIVO','CERRADO') NOT NULL DEFAULT 'ACTIVO',
 UNIQUE KEY uq_grupo(periodo_id,carrera_id,curso,paralelo,turno),
 FOREIGN KEY(periodo_id) REFERENCES periodos(id),
 FOREIGN KEY(carrera_id) REFERENCES carreras(id),
 FOREIGN KEY(tutor_id) REFERENCES docentes(id),
 CHECK(curso BETWEEN 1 AND 6), CHECK(cupo BETWEEN 1 AND 1000)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS grupo_integrantes (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 grupo_id INT UNSIGNED NOT NULL,
 matricula_id INT UNSIGNED NOT NULL UNIQUE,
 fecha TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(grupo_id) REFERENCES grupos(id),
 FOREIGN KEY(matricula_id) REFERENCES matriculas(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS grupo_materias (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 grupo_id INT UNSIGNED NOT NULL,
 oferta_id INT UNSIGNED NOT NULL UNIQUE,
 FOREIGN KEY(grupo_id) REFERENCES grupos(id),
 FOREIGN KEY(oferta_id) REFERENCES ofertas(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
