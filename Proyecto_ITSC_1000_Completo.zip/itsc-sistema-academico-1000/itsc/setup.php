<?php
// Instalador únicamente por consola. No tiene ruta HTTP utilizable.
if(PHP_SAPI!=='cli'){http_response_code(404);exit;}
$p=new PDO('mysql:host=127.0.0.1;port=3306;dbname=itsc_academico_v3;charset=utf8mb4','root',getenv('ITSC_ROOT_PASSWORD')?:'',[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);
$p->exec(file_get_contents(__DIR__.'/grupos.sql'));
$p->exec("CREATE TABLE IF NOT EXISTS app_usuarios(id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,usuario VARCHAR(60) NOT NULL UNIQUE,nombre VARCHAR(120) NOT NULL,password_hash VARCHAR(255) NOT NULL,rol ENUM('ADMIN','DOCENTE','CAJA') NOT NULL,docente_id INT UNSIGNED NULL,activo BOOLEAN NOT NULL DEFAULT 1,FOREIGN KEY(docente_id) REFERENCES docentes(id),CHECK(rol<>'DOCENTE' OR docente_id IS NOT NULL)) ENGINE=InnoDB");
$p->exec("CREATE TABLE IF NOT EXISTS app_auditoria(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,usuario_id INT UNSIGNED NOT NULL,accion VARCHAR(60) NOT NULL,entidad VARCHAR(80) NOT NULL,registro_id VARCHAR(50) NULL,fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(usuario_id) REFERENCES app_usuarios(id)) ENGINE=InnoDB");
$p->exec("CREATE TABLE IF NOT EXISTS app_intentos(clave CHAR(64) PRIMARY KEY,fallos INT NOT NULL DEFAULT 0,ultimo DATETIME NOT NULL) ENGINE=InnoDB");
$config=__DIR__.'/config.php';
if(!file_exists($config)){
 $dbpass=bin2hex(random_bytes(24));$dbuser='itsc_app_'.bin2hex(random_bytes(4));
 $p->exec("CREATE USER '".$dbuser."'@'localhost' IDENTIFIED BY ".$p->quote($dbpass));
 $p->exec("GRANT SELECT,INSERT,UPDATE,EXECUTE ON itsc_academico_v3.* TO '".$dbuser."'@'localhost'");
 file_put_contents($config,"<?php\nreturn ".var_export(['port'=>3306,'user'=>$dbuser,'password'=>$dbpass],true).";\n");
}
$runtime=require $config;
foreach(['grupo_integrantes','grupo_materias','horarios'] as $groupTable)$p->exec('GRANT DELETE ON itsc_academico_v3.'.$groupTable.' TO '.$p->quote($runtime['user'])."@'localhost'");
if(!(int)$p->query('SELECT COUNT(*) FROM app_usuarios')->fetchColumn()){
 $pass='SCz-'.bin2hex(random_bytes(8)).'!';
 $s=$p->prepare("INSERT INTO app_usuarios(usuario,nombre,password_hash,rol) VALUES('admin','Administrador de práctica',?,'ADMIN')");$s->execute([password_hash($pass,PASSWORD_DEFAULT)]);
 echo "USUARIO=admin\nCLAVE=$pass\n";
}else echo "Instalación actualizada; se conservaron los usuarios existentes.\n";
echo "URL=http://localhost/itsc/\n";
