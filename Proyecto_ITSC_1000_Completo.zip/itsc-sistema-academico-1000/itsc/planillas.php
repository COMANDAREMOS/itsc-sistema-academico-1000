<?php
function rosterModules():array{return [
 'notas_grupo'=>['title'=>'Planilla de notas por grupo','desc'=>'Elige grupo, materia y evaluación para cargar las notas de la lista. Los campos vacíos conservan las notas existentes.','fields'=>[]],
 'asistencia_grupo'=>['title'=>'Planilla de asistencia por grupo','desc'=>'Registra los minutos de asistencia de toda la lista para una sesión realizada. Cero representa ausencia; vacío conserva el registro.','fields'=>[]]
 ];}
function rosterGroups():array{
 [$f,$args]=offerFilter();
 return rows("SELECT g.id,CONCAT(p.nombre,' · ',c.codigo,' · ',g.curso,'° ',g.paralelo,' · ',g.turno) AS label FROM grupos g JOIN periodos p ON p.id=g.periodo_id JOIN carreras c ON c.id=g.carrera_id WHERE EXISTS(SELECT 1 FROM grupo_materias gm JOIN ofertas o ON o.id=gm.oferta_id WHERE gm.grupo_id=g.id $f) ORDER BY p.fecha_inicio DESC,c.nombre,g.curso,g.paralelo",$args);
}
function rosterId($value):int{
 if(!is_scalar($value)||!preg_match('/^[1-9][0-9]{0,9}$/D',(string)$value)||(float)$value>2147483647)throw new DomainException('Selecciona un registro válido.');
 return (int)$value;
}
function rosterOffer(int $groupId,int $offerId,bool $write=false):array{
 if($write)groupLock($groupId);
 $offer=one('SELECT o.* FROM ofertas o JOIN grupo_materias gm ON gm.oferta_id=o.id WHERE gm.grupo_id=? AND o.id=?',[$groupId,$offerId]);
 if(!$offer)throw new DomainException('La materia no pertenece al grupo seleccionado.');
 if(user()['rol']==='DOCENTE'&&(int)$offer['docente_id']!==(int)user()['docente_id'])throw new DomainException('No tienes acceso a esta materia.');
 return $write?lockOffer($offerId):$offer;
}
function rosterRows(int $groupId,int $offerId):array{
 return rows("SELECT i.id,e.registro,CONCAT(e.apellidos,' ',e.nombres) AS estudiante FROM inscripciones i JOIN matriculas mt ON mt.id=i.matricula_id JOIN grupo_integrantes gi ON gi.matricula_id=mt.id JOIN estudiantes e ON e.id=mt.estudiante_id WHERE gi.grupo_id=? AND i.oferta_id=? AND i.estado<>'RETIRADA' AND mt.estado='ACTIVA' ORDER BY e.apellidos,e.nombres,e.id",[$groupId,$offerId]);
}
function rosterMutate(string $page):void{
 if(!can($page,true))throw new DomainException('No tienes permiso para registrar esta planilla.');
 $gid=integer('grupo_id');$offerId=integer('oferta_id');rosterOffer($gid,$offerId,true);
 $grades=$page==='notas_grupo';$key=$grades?'notas':'minutos';$input=$_POST[$key]??null;
 if(!is_array($input)||count($input)>200)throw new DomainException('La planilla admite hasta 200 filas por operación.');
 $selectedId=integer($grades?'evaluacion_id':'sesion_id');
 if($grades){$selected=one('SELECT * FROM evaluaciones WHERE id=? AND oferta_id=?',[$selectedId,$offerId]);}
 else{$selected=one("SELECT *,TIMESTAMPDIFF(MINUTE,inicio,fin) AS duracion FROM sesiones WHERE id=? AND oferta_id=? AND estado='REALIZADA'",[$selectedId,$offerId]);}
 if(!$selected)throw new DomainException('La evaluación o sesión no corresponde a esta materia.');
 $allowed=array_column(rosterRows($gid,$offerId),null,'id');$saved=0;
 foreach($input as $id=>$value){
  $id=rosterId($id);if(!isset($allowed[$id]))throw new DomainException('La planilla contiene un estudiante ajeno al grupo o a la materia.');
  if(!is_scalar($value))throw new DomainException('Valor inválido en la planilla.');$value=trim((string)$value);if($value==='')continue;
  if($grades){
   if(!preg_match('/^\d{1,3}(?:\.\d{1,2})?$/D',$value)||(float)$value<1||(float)$value>100)throw new DomainException('Cada nota debe estar entre 1 y 100, con hasta dos decimales.');
   query('INSERT INTO calificaciones(inscripcion_id,evaluacion_id,oferta_id,nota) VALUES(?,?,?,?) ON DUPLICATE KEY UPDATE nota=VALUES(nota)',[$id,$selectedId,$offerId,$value]);
  }else{
   if(!ctype_digit($value)||(float)$value>(int)$selected['duracion'])throw new DomainException('Los minutos deben ser enteros entre cero y la duración de la sesión.');
   query('INSERT INTO asistencias_sesion(inscripcion_id,sesion_id,oferta_id,minutos_presentes) VALUES(?,?,?,?) ON DUPLICATE KEY UPDATE minutos_presentes=VALUES(minutos_presentes)',[$id,$selectedId,$offerId,(int)$value]);
  }
  $saved++;
 }
 if(!$saved)throw new DomainException('Completa al menos un valor para guardar la planilla.');
 audit('GUARDAR_PLANILLA',$page,$selectedId);$GLOBALS['saveMessage']='Planilla guardada: '.$saved.' registros. Los campos vacíos no se modificaron.';
}
function rosterSelect(string $name,string $label,array $options,$selected):void{
 echo '<label class="field"><span>'.e($label).'</span><select name="'.e($name).'"><option value="">Seleccionar…</option>';
 foreach($options as $o)echo '<option value="'.e($o['id']).'" '.((string)$selected===(string)$o['id']?'selected':'').'>'.e($o['label']).'</option>';echo '</select></label>';
}
function rosterRender(string $page):void{
 $grades=$page==='notas_grupo';$gid=isset($_GET['grupo'])&&$_GET['grupo']!==''?rosterId($_GET['grupo']):0;
 $offerId=isset($_GET['oferta'])&&$_GET['oferta']!==''?rosterId($_GET['oferta']):0;
 $key=$grades?'evaluacion':'sesion';$selectedId=isset($_GET[$key])&&$_GET[$key]!==''?rosterId($_GET[$key]):0;
 $groups=rosterGroups();if($gid&&!in_array($gid,array_map('intval',array_column($groups,'id')),true))throw new DomainException('No hay materias autorizadas para ese grupo.');
 [$f,$args]=offerFilter();
 $offers=$gid?rows("SELECT o.id,CONCAT(ma.nombre,' · ',o.paralelo,' · ',o.turno) AS label FROM grupo_materias gm JOIN ofertas o ON o.id=gm.oferta_id JOIN materias ma ON ma.id=o.materia_id WHERE gm.grupo_id=? $f ORDER BY ma.nombre",[$gid,...$args]):[];
 if($offerId)rosterOffer($gid,$offerId);
 $choices=$offerId?($grades?rows('SELECT id,CONCAT(nombre,\' · \',componente) AS label FROM evaluaciones WHERE oferta_id=? ORDER BY id',[$offerId]):rows("SELECT id,CONCAT(inicio,' · ',TIMESTAMPDIFF(MINUTE,inicio,fin),' minutos') AS label FROM sesiones WHERE oferta_id=? AND estado='REALIZADA' ORDER BY inicio DESC",[$offerId])):[];
 echo '<section class="panel"><form method="get" class="inline-form"><input type="hidden" name="p" value="'.e($page).'">';
 rosterSelect('grupo','Grupo',$groups,$gid);rosterSelect('oferta','Materia / oferta',$offers,$offerId);rosterSelect($key,$grades?'Evaluación':'Sesión realizada',$choices,$selectedId);
 echo '<button class="button">Cargar lista</button></form><p class="group-help">Selecciona un grupo y carga sus materias. Después elige la materia y la evaluación o sesión. Si faltan opciones, créalas en Evaluaciones o Sesiones de clase.</p></section>';
 if(!$gid||!$offerId||!$selectedId){echo '<section class="panel empty">Elige los tres filtros para abrir la planilla. Las materias deben estar vinculadas al grupo y los estudiantes inscritos.</section>';return;}
 $selected=$grades?one('SELECT * FROM evaluaciones WHERE id=? AND oferta_id=?',[$selectedId,$offerId]):one("SELECT *,TIMESTAMPDIFF(MINUTE,inicio,fin) AS duracion FROM sesiones WHERE id=? AND oferta_id=? AND estado='REALIZADA'",[$selectedId,$offerId]);
 if(!$selected)throw new DomainException('La evaluación o sesión no corresponde a la materia.');
 $all=rosterRows($gid,$offerId);$number=max(1,min((int)($_GET['pagina']??1),max(1,(int)ceil(count($all)/200))));$list=array_slice($all,($number-1)*200,200);
 $existing=$grades?rows('SELECT inscripcion_id,nota AS valor FROM calificaciones WHERE evaluacion_id=?',[$selectedId]):rows('SELECT inscripcion_id,minutos_presentes AS valor FROM asistencias_sesion WHERE sesion_id=?',[$selectedId]);$values=array_column($existing,'valor','inscripcion_id');
 if(!$list){echo '<section class="panel empty">No hay estudiantes inscritos en esta materia dentro del grupo. Utiliza la inscripción por grupo.</section>';return;}
 $closed=one('SELECT oferta_id FROM cierres_oferta WHERE oferta_id=?',[$offerId])||one("SELECT id FROM grupos WHERE id=? AND estado='CERRADO'",[$gid]);
 echo '<section class="panel"><h2>'.($grades?'Notas de la evaluación':'Asistencia de la sesión').'</h2><p>'.count($all).' estudiantes inscritos · Página '.$number.' · Hasta 200 filas por guardado.</p>';
 if($closed)echo '<div class="notice">Grupo u oferta cerrados: consulta disponible, edición bloqueada.</div>';
 echo '<form method="post" class="roster-form">';token();foreach(['action'=>'save','grupo_id'=>$gid,'oferta_id'=>$offerId,$grades?'evaluacion_id':'sesion_id'=>$selectedId] as $name=>$value)echo '<input type="hidden" name="'.e($name).'" value="'.e($value).'">';
 if(!$grades&&!$closed)echo '<div class="roster-tools"><button type="button" class="button secondary" data-attendance-fill="'.e($selected['duracion']).'">Marcar presentes en esta página</button><button type="button" class="button secondary" data-attendance-fill="0">Marcar ausentes en esta página</button></div>';
 echo '<div class="table-wrap"><table><thead><tr><th>Registro</th><th>Estudiante</th><th>'.($grades?'Nota de 1 a 100':'Minutos de 0 a '.e($selected['duracion'])).'</th></tr></thead><tbody>';
 foreach($list as $student){$id=$student['id'];echo '<tr><td>'.e($student['registro']).'</td><td>'.e($student['estudiante']).'</td><td><input class="roster-value" aria-label="'.($grades?'Nota de ':'Minutos de ').e($student['estudiante']).'" type="number" name="'.($grades?'notas':'minutos').'['.e($id).']" min="'.($grades?'1':'0').'" max="'.($grades?'100':e($selected['duracion'])).'" step="'.($grades?'0.01':'1').'" value="'.e($values[$id]??'').'" '.($closed?'disabled':'').'></td></tr>';}
 echo '</tbody></table></div>';if(!$closed)echo '<div class="form-footer"><span>Vacío: conservar sin cambios. Se guarda toda la página o se rechaza completa.</span><button class="button">Guardar planilla</button></div>';echo '</form>';
 $pages=max(1,(int)ceil(count($all)/200));for($n=1;$n<=$pages;$n++)echo '<a class="text-button" href="index.php?'.e(http_build_query(['p'=>$page,'grupo'=>$gid,'oferta'=>$offerId,$key=>$selectedId,'pagina'=>$n])).'">Página '.$n.'</a>';echo '</section>';
}
