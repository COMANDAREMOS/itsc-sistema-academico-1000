<?php
// setup.php genera config.php por consola con una cuenta de base dedicada.
return ['port'=>3306,'user'=>'USUARIO_DE_BASE','password'=>'CONTRASEÑA_DE_BASE'];
